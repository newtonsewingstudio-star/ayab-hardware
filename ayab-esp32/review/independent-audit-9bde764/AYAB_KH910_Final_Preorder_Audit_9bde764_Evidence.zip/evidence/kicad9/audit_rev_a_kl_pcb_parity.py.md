# KH910 Rev A — K/L PCB Parity Audit

Read-only inventory of the current repository PCB. The validated schematic separates the KH910 machine K/L inputs from the retained U701/J702 level-shifter channels.

## Footprints and pad nets

### J202 — SPARE0
- footprint: (126.6200, 120.3000) rot 90.0
- pad 1: (126.6200, 120.3000) net `/ESP32/FRONT_PANEL_AUX` (#109)
- pad 2: (129.1600, 120.3000) net `/BROTHER-CONNECTORS/EOL_R_N` (#69)
- pad 3: (131.7000, 120.3000) net `/BROTHER-CONNECTORS/EOL_R_S` (#70)
- pad 4: (134.2400, 120.3000) net `SOLENOID_PWR_EN` (#138)

### J405 — 910.950 ENCODERS EOL R
- footprint: (280.9300, 145.1700) rot 180.0
- pad 1: (290.9300, 145.1700) net `+5V` (#5)
- pad 2: (288.4300, 145.1700) net `GND` (#2)
- pad 3: (285.9300, 145.1700) net `unconnected-(J405-Pin_3-Pad3)` (#20)
- pad 4: (283.4300, 145.1700) net `/BROTHER-CONNECTORS/ENC_V1` (#66)
- pad 5: (280.9300, 145.1700) net `/BROTHER-CONNECTORS/ENC_V2` (#65)
- pad 6: (278.4300, 145.1700) net `/BROTHER-CONNECTORS/ENC_BELTPHASE` (#67)
- pad 7: (275.9300, 145.1700) net `/BROTHER-CONNECTORS/EOL_R_S` (#70)
- pad 8: (273.4300, 145.1700) net `/BROTHER-CONNECTORS/EOL_R_N` (#69)
- pad 9: (270.9300, 145.1700) net `Net-(J405-Pin_9)` (#97)
- pad 10: (268.4300, 145.1700) net `Net-(J405-Pin_10)` (#98)

### J702 — CTRL_5V
- footprint: (184.6500, 152.4900) rot 0.0
- pad 1: (184.6500, 152.4900) net `/BROTHER-CONNECTORS/ENC_V1` (#66)
- pad 2: (187.1900, 152.4900) net `/BROTHER-CONNECTORS/ENC_V2` (#65)
- pad 3: (184.6500, 155.0300) net `/BROTHER-CONNECTORS/ENC_BELTPHASE` (#67)
- pad 4: (187.1900, 155.0300) net `Net-(J702-Pin_4)` (#37)
- pad 5: (184.6500, 157.5700) net `Net-(J702-Pin_5)` (#38)
- pad 6: (187.1900, 157.5700) net `Net-(J702-Pin_6)` (#145)
- pad 7: (184.6500, 160.1100) net `Net-(J702-Pin_7)` (#146)
- pad 8: (187.1900, 160.1100) net `Net-(J702-Pin_8)` (#71)

### R213 — 10k
- footprint: (260.0000, 124.0000) rot 0.0
- pad 1: (259.1750, 124.0000) net `+3V3` (#6)
- pad 2: (260.8250, 124.0000) net `/BROTHER-CONNECTORS/EOL_R_N` (#69)

### R214 — 10k
- footprint: (260.0000, 126.0000) rot 0.0
- pad 1: (259.1750, 126.0000) net `+3V3` (#6)
- pad 2: (260.8250, 126.0000) net `/BROTHER-CONNECTORS/EOL_R_S` (#70)

### R711 — 10k
- footprint: (177.8375, 159.5382) rot 180.0
- pad 1: (178.6625, 159.5382) net `Net-(J702-Pin_6)` (#145)
- pad 2: (177.0125, 159.5382) net `GND` (#2)

### R712 — 10k
- footprint: (180.8875, 159.5382) rot 180.0
- pad 1: (181.7125, 159.5382) net `+5V` (#5)
- pad 2: (180.0625, 159.5382) net `Net-(J702-Pin_6)` (#145)

### R713 — 10k
- footprint: (177.8375, 161.1591) rot 180.0
- pad 1: (178.6625, 161.1591) net `Net-(J702-Pin_7)` (#146)
- pad 2: (177.0125, 161.1591) net `GND` (#2)

### R714 — 10k
- footprint: (180.8875, 161.1591) rot 180.0
- pad 1: (181.7125, 161.1591) net `+5V` (#5)
- pad 2: (180.0625, 161.1591) net `Net-(J702-Pin_7)` (#146)

### U201 — ESP32-S3-MINI-1
- footprint: (224.1250, 129.6750) rot 0.0
- pad 1: (217.1250, 123.7250) net `GND` (#2)
- pad 2: (217.1250, 124.5750) net `GND` (#2)
- pad 3: (217.1250, 125.4250) net `+3V3` (#6)
- pad 4: (217.1250, 126.2750) net `/ESP32/BOOT0` (#25)
- pad 5: (217.1250, 127.1250) net `/ESP32/HALL_L_ADC` (#143)
- pad 6: (217.1250, 127.9750) net `/ESP32/HALL_R_ADC` (#144)
- pad 7: (217.1250, 128.8250) net `unconnected-(U201-GPIO3{slash}TOUCH3{slash}ADC1_CH2-Pad7)` (#151)
- pad 8: (217.1250, 129.6750) net `/ESP32/MACHINE_PWR_SENSE` (#150)
- pad 9: (217.1250, 130.5250) net `/ESP32/ENC_A` (#31)
- pad 10: (217.1250, 131.3750) net `/ESP32/ENC_B` (#32)
- pad 11: (217.1250, 132.2250) net `/ESP32/ENC_BP` (#33)
- pad 12: (217.1250, 133.0750) net `/AUX-CONNECTORS/AYAB_SDA` (#89)
- pad 13: (217.1250, 133.9250) net `/AUX-CONNECTORS/AYAB_SCL` (#88)
- pad 14: (217.1250, 134.7750) net `/AUX-CONNECTORS/AYAB_CS` (#77)
- pad 15: (217.1250, 135.6250) net `/AUX-CONNECTORS/AYAB_CIPO` (#94)
- pad 16: (218.1750, 136.6750) net `/AUX-CONNECTORS/AYAB_COPI` (#78)
- pad 17: (219.0250, 136.6750) net `/AUX-CONNECTORS/AYAB_SCK` (#80)
- pad 18: (219.8750, 136.6750) net `/ESP32/FRONT_PANEL_AUX` (#109)
- pad 19: (220.7250, 136.6750) net `/AUX-CONNECTORS/I2C_SDA` (#91)
- pad 20: (221.5750, 136.6750) net `/AUX-CONNECTORS/I2C_SCL` (#90)
- pad 21: (222.4250, 136.6750) net `/BROTHER-CONNECTORS/EOL_R_N` (#69)
- pad 22: (223.2750, 136.6750) net `/BROTHER-CONNECTORS/EOL_R_S` (#70)
- pad 23: (224.1250, 136.6750) net `/ESP32/USB_M` (#1)
- pad 24: (224.9750, 136.6750) net `/ESP32/USB_P` (#3)
- pad 25: (225.8250, 136.6750) net `SOLENOID_PWR_EN` (#138)
- pad 26: (226.6750, 136.6750) net `unconnected-(U201-GPIO26-Pad26)` (#28)
- pad 27: (227.5250, 136.6750) net `unconnected-(U201-GPIO47{slash}SPICLK_P{slash}SUBSPICLK_P_DIFF-Pad27)` (#103)
- pad 28: (228.3750, 136.6750) net `/ESP32/RED` (#45)
- pad 29: (229.2250, 136.6750) net `/ESP32/GRN` (#43)
- pad 30: (230.0750, 136.6750) net `unconnected-(U201-GPIO48{slash}SPICLK_N{slash}SUBSPICLK_N_DIFF-Pad30)` (#104)
- pad 31: (231.1250, 135.6250) net `/ESP32/YEL` (#41)
- pad 32: (231.1250, 134.7750) net `/ESP32/USER_BUTTON` (#40)
- pad 33: (231.1250, 133.9250) net `unconnected-(U201-SPIDQS{slash}GPIO37{slash}FSPIQ{slash}SUBSPIQ-Pad33)` (#105)
- pad 34: (231.1250, 133.0750) net `/ESP32/BUZZER` (#21)
- pad 35: (231.1250, 132.2250) net `/ESP32/PANEL_INT` (#102)
- pad 36: (231.1250, 131.3750) net `/ESP32/ESP40` (#106)
- pad 37: (231.1250, 130.5250) net `/ESP32/ESP41` (#107)
- pad 38: (231.1250, 129.6750) net `/ESP32/ESP42` (#108)
- pad 39: (231.1250, 128.8250) net `/AUX-CONNECTORS/UART_TX` (#93)
- pad 40: (231.1250, 127.9750) net `/AUX-CONNECTORS/UART_RX` (#92)
- pad 41: (231.1250, 127.1250) net `/ESP32/VCC_SPI` (#34)
- pad 42: (231.1250, 126.2750) net `GND` (#2)
- pad 43: (231.1250, 125.4250) net `GND` (#2)
- pad 44: (231.1250, 124.5750) net `/ESP32/BOOT1` (#35)
- pad 45: (231.1250, 123.7250) net `/ESP32/nRST` (#36)
- pad 46: (230.0750, 122.6750) net `GND` (#2)
- pad 47: (229.2250, 122.6750) net `GND` (#2)
- pad 48: (228.3750, 122.6750) net `GND` (#2)
- pad 49: (227.5250, 122.6750) net `GND` (#2)
- pad 50: (226.6750, 122.6750) net `GND` (#2)
- pad 51: (225.8250, 122.6750) net `GND` (#2)
- pad 52: (224.9750, 122.6750) net `GND` (#2)
- pad 53: (224.1250, 122.6750) net `GND` (#2)
- pad 54: (223.2750, 122.6750) net `GND` (#2)
- pad 55: (222.4250, 122.6750) net `GND` (#2)
- pad 56: (221.5750, 122.6750) net `GND` (#2)
- pad 57: (220.7250, 122.6750) net `GND` (#2)
- pad 58: (219.8750, 122.6750) net `GND` (#2)
- pad 59: (219.0250, 122.6750) net `GND` (#2)
- pad 60: (218.1750, 122.6750) net `GND` (#2)
- pad 61: (222.4750, 128.0250) net `GND` (#2)
- pad 61: (222.4750, 129.6750) net `GND` (#2)
- pad 61: (222.4750, 131.3250) net `GND` (#2)
- pad 61: (224.1250, 128.0250) net `GND` (#2)
- pad 61: (224.1250, 129.6750) net `GND` (#2)
- pad 61: (224.1250, 131.3250) net `GND` (#2)
- pad 61: (225.7750, 128.0250) net `GND` (#2)
- pad 61: (225.7750, 129.6750) net `GND` (#2)
- pad 61: (225.7750, 131.3250) net `GND` (#2)
- pad 62: (217.1250, 122.6750) net `GND` (#2)
- pad 63: (217.1250, 136.6750) net `GND` (#2)
- pad 64: (231.1250, 136.6750) net `GND` (#2)
- pad 65: (231.1250, 122.6750) net `GND` (#2)

### U701 — SN74LVC4245
- footprint: (194.3400, 157.5300) rot 0.0
- pad 1: (191.4775, 153.9550) net `+5V` (#5)
- pad 2: (191.4775, 154.6050) net `+5V` (#5)
- pad 3: (191.4775, 155.2550) net `/BROTHER-CONNECTORS/ENC_V1` (#66)
- pad 4: (191.4775, 155.9050) net `/BROTHER-CONNECTORS/ENC_V2` (#65)
- pad 5: (191.4775, 156.5550) net `/BROTHER-CONNECTORS/ENC_BELTPHASE` (#67)
- pad 6: (191.4775, 157.2050) net `Net-(J702-Pin_4)` (#37)
- pad 7: (191.4775, 157.8550) net `Net-(J702-Pin_5)` (#38)
- pad 8: (191.4775, 158.5050) net `Net-(J702-Pin_6)` (#145)
- pad 9: (191.4775, 159.1550) net `Net-(J702-Pin_7)` (#146)
- pad 10: (191.4775, 159.8050) net `Net-(J702-Pin_8)` (#71)
- pad 11: (191.4775, 160.4550) net `GND` (#2)
- pad 12: (191.4775, 161.1050) net `GND` (#2)
- pad 13: (197.2025, 161.1050) net `GND` (#2)
- pad 14: (197.2025, 160.4550) net `Net-(J701-Pin_8)` (#68)
- pad 15: (197.2025, 159.8050) net `Net-(J701-Pin_7)` (#30)
- pad 16: (197.2025, 159.1550) net `Net-(J701-Pin_6)` (#29)
- pad 17: (197.2025, 158.5050) net `Net-(J701-Pin_5)` (#27)
- pad 18: (197.2025, 157.8550) net `Net-(J701-Pin_4)` (#26)
- pad 19: (197.2025, 157.2050) net `/ESP32/ENC_BP` (#33)
- pad 20: (197.2025, 156.5550) net `/ESP32/ENC_B` (#32)
- pad 21: (197.2025, 155.9050) net `/ESP32/ENC_A` (#31)
- pad 22: (197.2025, 155.2550) net `GND` (#2)
- pad 23: (197.2025, 154.6050) net `+3V3` (#6)
- pad 24: (197.2025, 153.9550) net `+3V3` (#6)

## Matching board nets and connected pads

### net 69: `/BROTHER-CONNECTORS/EOL_R_N`

- J202.2 at (129.1600, 120.3000)
- J405.8 at (273.4300, 145.1700)
- R213.2 at (260.8250, 124.0000)
- U201.21 at (222.4250, 136.6750)

### net 70: `/BROTHER-CONNECTORS/EOL_R_S`

- J202.3 at (131.7000, 120.3000)
- J405.7 at (275.9300, 145.1700)
- R214.2 at (260.8250, 126.0000)
- U201.22 at (223.2750, 136.6750)

### net 145: `Net-(J702-Pin_6)`

- J702.6 at (187.1900, 157.5700)
- R711.1 at (178.6625, 159.5382)
- R712.2 at (180.0625, 159.5382)
- U701.8 at (191.4775, 158.5050)

### net 146: `Net-(J702-Pin_7)`

- J702.7 at (184.6500, 160.1100)
- R713.1 at (178.6625, 161.1591)
- R714.2 at (180.0625, 161.1591)
- U701.9 at (191.4775, 159.1550)

## Copper on matching nets

- `/BROTHER-CONNECTORS/EOL_R_N` F.Cu: (260.8250, 124.0000) -> (262.0000, 124.0000)
- `/BROTHER-CONNECTORS/EOL_R_N` F.Cu: (222.4250, 135.6050) -> (220.9700, 134.1500)
- `/BROTHER-CONNECTORS/EOL_R_N` F.Cu: (272.1700, 143.9100) -> (273.4300, 145.1700)
- `/BROTHER-CONNECTORS/EOL_R_N` F.Cu: (266.9049, 143.9100) -> (272.1700, 143.9100)
- `/BROTHER-CONNECTORS/EOL_R_N` F.Cu: (239.2200, 145.6500) -> (265.1649, 145.6500)
- `/BROTHER-CONNECTORS/EOL_R_N` F.Cu: (222.4250, 136.6750) -> (222.4250, 135.6050)
- `/BROTHER-CONNECTORS/EOL_R_N` F.Cu: (265.1649, 145.6500) -> (266.9049, 143.9100)
- `/BROTHER-CONNECTORS/EOL_R_N` via at (239.2200, 145.6500)
- `/BROTHER-CONNECTORS/EOL_R_N` via at (220.9700, 134.1500)
- `/BROTHER-CONNECTORS/EOL_R_N` via at (262.0000, 124.0000)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (240.0000, 144.4000) -> (240.2000, 144.4000)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (262.8000, 124.0000) -> (261.6000, 125.2000)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (239.8000, 144.2000) -> (240.0000, 144.4000)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (129.7550, 120.3000) -> (140.3650, 130.9100)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (217.7300, 130.9100) -> (220.9700, 134.1500)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (129.1600, 120.3000) -> (129.7550, 120.3000)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (239.8000, 130.8000) -> (239.8000, 144.2000)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (240.2000, 144.4000) -> (239.2200, 145.6500)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (140.3650, 130.9100) -> (217.7300, 130.9100)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (262.0000, 124.0000) -> (262.8000, 124.0000)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (245.4000, 125.2000) -> (239.8000, 130.8000)
- `/BROTHER-CONNECTORS/EOL_R_N` B.Cu: (261.6000, 125.2000) -> (245.4000, 125.2000)
- `/BROTHER-CONNECTORS/EOL_R_N` In2.Cu: (227.4000, 132.8000) -> (226.6000, 132.0000)
- `/BROTHER-CONNECTORS/EOL_R_N` In2.Cu: (226.6000, 132.0000) -> (226.6000, 131.8000)
- `/BROTHER-CONNECTORS/EOL_R_N` In2.Cu: (234.2000, 132.8000) -> (227.4000, 132.8000)
- `/BROTHER-CONNECTORS/EOL_R_N` In2.Cu: (239.2200, 145.6500) -> (240.2000, 144.4000)
- `/BROTHER-CONNECTORS/EOL_R_N` In2.Cu: (226.6000, 131.8000) -> (221.2000, 131.8000)
- `/BROTHER-CONNECTORS/EOL_R_N` In2.Cu: (220.0000, 133.2000) -> (220.9700, 134.1500)
- `/BROTHER-CONNECTORS/EOL_R_N` In2.Cu: (220.0000, 133.0000) -> (220.0000, 133.2000)
- `/BROTHER-CONNECTORS/EOL_R_N` In2.Cu: (240.2000, 138.8000) -> (234.2000, 132.8000)
- `/BROTHER-CONNECTORS/EOL_R_N` In2.Cu: (221.2000, 131.8000) -> (220.0000, 133.0000)
- `/BROTHER-CONNECTORS/EOL_R_N` In2.Cu: (240.2000, 144.4000) -> (240.2000, 138.8000)
- `/BROTHER-CONNECTORS/EOL_R_S` F.Cu: (238.4500, 145.6300) -> (238.8300, 145.2500)
- `/BROTHER-CONNECTORS/EOL_R_S` F.Cu: (274.4700, 143.7100) -> (275.9300, 145.1700)
- `/BROTHER-CONNECTORS/EOL_R_S` F.Cu: (223.2750, 136.6750) -> (223.2750, 135.7450)
- `/BROTHER-CONNECTORS/EOL_R_S` F.Cu: (238.8300, 145.2500) -> (265.2820, 145.2500)
- `/BROTHER-CONNECTORS/EOL_R_S` F.Cu: (265.2820, 145.2500) -> (266.8220, 143.7100)
- `/BROTHER-CONNECTORS/EOL_R_S` F.Cu: (266.8220, 143.7100) -> (274.4700, 143.7100)
- `/BROTHER-CONNECTORS/EOL_R_S` F.Cu: (223.2750, 135.7450) -> (221.6700, 134.1400)
- `/BROTHER-CONNECTORS/EOL_R_S` F.Cu: (260.8250, 126.0000) -> (262.0000, 126.0000)
- `/BROTHER-CONNECTORS/EOL_R_S` via at (238.4500, 145.6300)
- `/BROTHER-CONNECTORS/EOL_R_S` via at (262.0000, 126.0000)
- `/BROTHER-CONNECTORS/EOL_R_S` via at (221.6700, 134.1400)
- `/BROTHER-CONNECTORS/EOL_R_S` B.Cu: (218.2400, 130.7100) -> (142.7050, 130.7100)
- `/BROTHER-CONNECTORS/EOL_R_S` B.Cu: (142.7050, 130.7100) -> (132.2950, 120.3000)
- `/BROTHER-CONNECTORS/EOL_R_S` B.Cu: (221.6700, 134.1400) -> (218.2400, 130.7100)
- `/BROTHER-CONNECTORS/EOL_R_S` B.Cu: (132.2950, 120.3000) -> (131.7000, 120.3000)
- `/BROTHER-CONNECTORS/EOL_R_S` In1.Cu: (262.0000, 126.0000) -> (262.8000, 126.0000)
- `/BROTHER-CONNECTORS/EOL_R_S` In1.Cu: (262.8000, 126.0000) -> (244.2000, 144.6000)
- `/BROTHER-CONNECTORS/EOL_R_S` In1.Cu: (238.4500, 144.6000) -> (238.4500, 145.6300)
- `/BROTHER-CONNECTORS/EOL_R_S` In1.Cu: (244.2000, 144.6000) -> (238.4500, 144.6000)
- `/BROTHER-CONNECTORS/EOL_R_S` In2.Cu: (223.0000, 134.8000) -> (221.6000, 134.8000)
- `/BROTHER-CONNECTORS/EOL_R_S` In2.Cu: (221.6000, 134.8000) -> (221.6000, 132.8000)
- `/BROTHER-CONNECTORS/EOL_R_S` In2.Cu: (221.6000, 132.8000) -> (221.6700, 132.6000)
- `/BROTHER-CONNECTORS/EOL_R_S` In2.Cu: (239.8000, 146.8000) -> (235.0000, 146.8000)
- `/BROTHER-CONNECTORS/EOL_R_S` In2.Cu: (235.0000, 146.8000) -> (223.0000, 134.8000)
- `/BROTHER-CONNECTORS/EOL_R_S` In2.Cu: (221.6700, 132.6000) -> (221.6700, 134.1400)
- `/BROTHER-CONNECTORS/EOL_R_S` In2.Cu: (238.4500, 145.6300) -> (239.8000, 146.8000)
- `Net-(J702-Pin_6)` F.Cu: (183.1409, 160.3591) -> (183.4800, 160.0200)
- `Net-(J702-Pin_6)` F.Cu: (185.9000, 158.8600) -> (187.1900, 157.5700)
- `Net-(J702-Pin_6)` F.Cu: (184.1200, 158.8600) -> (185.9000, 158.8600)
- `Net-(J702-Pin_6)` F.Cu: (180.8833, 160.3591) -> (183.1409, 160.3591)
- `Net-(J702-Pin_6)` F.Cu: (189.5500, 157.5700) -> (190.4850, 158.5050)
- `Net-(J702-Pin_6)` F.Cu: (183.4800, 159.5000) -> (184.1200, 158.8600)
- `Net-(J702-Pin_6)` F.Cu: (180.0625, 159.5382) -> (180.8833, 160.3591)
- `Net-(J702-Pin_6)` F.Cu: (190.4850, 158.5050) -> (191.4775, 158.5050)
- `Net-(J702-Pin_6)` F.Cu: (187.1900, 157.5700) -> (189.5500, 157.5700)
- `Net-(J702-Pin_6)` F.Cu: (178.6625, 159.5382) -> (180.0625, 159.5382)
- `Net-(J702-Pin_6)` F.Cu: (183.4800, 160.0200) -> (183.4800, 159.5000)
- `Net-(J702-Pin_7)` F.Cu: (184.6500, 160.1100) -> (185.3300, 160.1100)
- `Net-(J702-Pin_7)` F.Cu: (184.6500, 160.6700) -> (184.6500, 160.1100)
- `Net-(J702-Pin_7)` F.Cu: (185.3300, 160.1100) -> (186.4200, 159.0200)
- `Net-(J702-Pin_7)` F.Cu: (180.8625, 161.9591) -> (183.3609, 161.9591)
- `Net-(J702-Pin_7)` F.Cu: (186.4200, 159.0200) -> (191.3425, 159.0200)
- `Net-(J702-Pin_7)` F.Cu: (180.0625, 161.1591) -> (180.8625, 161.9591)
- `Net-(J702-Pin_7)` F.Cu: (191.3425, 159.0200) -> (191.4775, 159.1550)
- `Net-(J702-Pin_7)` F.Cu: (178.6625, 161.1591) -> (180.0625, 161.1591)
- `Net-(J702-Pin_7)` F.Cu: (183.3609, 161.9591) -> (184.6500, 160.6700)

## Parity interpretation

- J405 machine K/L pads must ultimately remain on the dedicated machine-signal nets that reach the ESP32 through the new pull-up stage.
- U701/J702 channels 6/7 must remain connected locally but must not remain electrically tied to J405 K/L after the Rev A PCB split.
- Do not fabricate until this split and the analog Hall migration both pass project-aware DRC.
