Read AYAB_KH910_Final_Preorder_Audit_9bde764.md first.
Base commit 9bde764c6e157920af34ccd1063949ac5dcc5109, plus isolated local script/document/test repairs.
Evidence only: no native source, invalid test fixture boards or fabrication files.
Repaired source is delivered in a separate source ZIP.
