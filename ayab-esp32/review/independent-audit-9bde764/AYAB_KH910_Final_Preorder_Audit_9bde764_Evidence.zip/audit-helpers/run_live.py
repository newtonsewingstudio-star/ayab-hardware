from audit_helpers import *
import os,shutil
major=sys.argv[1];src=SRC if major=='9' else BASE/'source-kicad10';dest=RES/f'kicad{major}';dest.mkdir(exist_ok=True)
bindir=BASE.parent/'independent-audit-647998e/kicad9-runtime/bin' if major=='9' else Path(r'C:\Program Files\KiCad\10.0\bin')
cli=bindir/'kicad-cli.exe';py=bindir/'python.exe';share=bindir.parent/'share/kicad'
cfg=dest/'config'/f'{major}.0';cfg.mkdir(parents=True,exist_ok=True);tmp=dest/'temp';tmp.mkdir(exist_ok=True)
for name in ['sym-lib-table','fp-lib-table']:shutil.copyfile(share/'template'/name,cfg/name)
env=os.environ.copy();env.update({'PATH':str(bindir)+os.pathsep+env['PATH'],'KICAD_CONFIG_HOME':str(cfg.parent),'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8','TEMP':str(tmp),'TMP':str(tmp),f'KICAD{major}_SYMBOL_DIR':str(share/'symbols'),f'KICAD{major}_FOOTPRINT_DIR':str(share/'footprints')})
save(f'kicad{major}/environment.json',{k:v for k,v in env.items() if k in ['KICAD_CONFIG_HOME','PYTHONDONTWRITEBYTECODE','PYTHONIOENCODING','TEMP','TMP',f'KICAD{major}_SYMBOL_DIR',f'KICAD{major}_FOOTPRINT_DIR']})
env['KICAD6_3DMODEL_DIR']=str(BASE/'standard-models')
save(f'kicad{major}/model-environment.json',{'KICAD6_3DMODEL_DIR':env['KICAD6_3DMODEL_DIR']})

def execute(name,args):
    r=run(args,src,env=env);save(f'kicad{major}/{name}.json',r);print(major,name,r['exit'],r['stdout'][:350],r['stderr'][:250],flush=True);return r
pcb='ayab-esp32/ayab-esp32.kicad_pcb';sch='ayab-esp32/ayab-esp32.kicad_sch'
execute('version',[cli,'version'])
execute('python-version',[py,'-c','import sys,pcbnew;print(sys.version);print(pcbnew.Version())'])
execute('drc',[cli,'pcb','drc','--exit-code-violations','-o',dest/'drc.rpt',pcb])
execute('drc-parity',[cli,'pcb','drc','--schematic-parity','--exit-code-violations','-o',dest/'drc-parity.rpt',pcb])
execute('erc',[cli,'sch','erc','--exit-code-violations','-o',dest/'erc.rpt',sch])
execute('netlist',[cli,'sch','export','netlist','--format','kicadxml','-o',dest/'live-netlist.xml',sch])
if major=='9':
    specs=[('audit_rev_a_power_pcb_parity.py',['--output',dest/'power-parity.md']),('validate_rev_a_machine_sense_protection.py',[pcb]),('audit_rev_a_prototype_pcb_parity.py',[]),('audit_rev_a_solenoid_gate_source.py',[]),('validate_rev_a_solenoid_failsafe_pcb.py',[pcb]),('audit_rev_a_hall_pcb_parity.py',None),('audit_rev_a_kl_pcb_parity.py',None),('audit_esp32_pinmap.py',None),('validate_rev_a_manufacturing_metadata.py',[])]
    for name,args in specs:
        script=Path('ayab-esp32/tools')/name
        cmd=[py,script,*args] if args is not None else [py,BASE/'redirect_report.py',script,dest/(name+'.md')]
        execute(name,cmd)
    for name,layers in [('front','F.Cu,F.SilkS,Edge.Cuts'),('back','B.Cu,B.SilkS,Edge.Cuts'),('front-outlines','F.Fab,F.CrtYd,Edge.Cuts'),('back-outlines','B.Fab,B.CrtYd,Edge.Cuts'),('inner1','In1.Cu,Edge.Cuts'),('inner2','In2.Cu,Edge.Cuts')]:
        execute(name,[cli,'pcb','export','svg','--mode-single','--page-size-mode','2','--layers',layers,'-o',dest/(name+'.svg'),pcb])
    execute('schematics',[cli,'sch','export','svg','-o',str(dest/'schematics')+os.sep,sch])
    for side in ['top','bottom']:
        execute('render-'+side,[cli,'pcb','render','--side',side,'--width','3600','--height','1000','--zoom','3','-o',dest/f'render-{side}.png',pcb])

if major=='10':
    for name,layers in [('front','F.Cu,F.SilkS,Edge.Cuts'),('back','B.Cu,B.SilkS,Edge.Cuts')]:
        execute(name,[cli,'pcb','export','svg','--mode-single','--page-size-mode','2','--layers',layers,'-o',dest/(name+'.svg'),pcb])
    for side in ['top','bottom']:
        execute('render-'+side,[cli,'pcb','render','--side',side,'--width','3600','--height','1000','--zoom','3','-o',dest/f'render-{side}.png',pcb])
