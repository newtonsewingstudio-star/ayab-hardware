from audit_helpers import *
import shutil,difflib,datetime
dest=BASE/'repaired-source';dest.mkdir(exist_ok=False)
tracked=json.loads((RES/'handoff-git-comparison.json').read_text())['rows']
for row in tracked:
    p=dest/row['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SRC/row['path'],p)
changed=[]
for rel in ['ayab-esp32/review/KH910_REV_A_FINAL_PREORDER_AUDIT_CLOSURE.md','ayab-esp32/review/KH910_REV_A_AUDIT_00B3978_REPAIR_CLOSURE.md']:
    p=dest/rel;data=p.read_bytes();assert data.count(b"TP701's `Package`")==1
    p.write_bytes(data.replace(b"TP701's `Package`",b"TP703's `Package`"));changed.append(rel)
rel='ayab-esp32/tools/validate_rev_a_manufacturing_metadata.py';p=dest/rel;data=p.read_bytes()
nl=b'\r\n' if b'\r\n' in data else b'\n'
old=nl.join([b'    courtyard_hits = []',b'    footprint_silk_hits = []',b'    for footprint in physical:'])
new=nl.join([b'    courtyard_hits = []',b'    footprint_silk_hits = []',b'    # Artwork footprints have no component reference but still obstruct silk.',b'    for footprint in board.GetFootprints():'])
assert data.count(old)==1;p.write_bytes(data.replace(old,new));changed.append(rel)
test='ayab-esp32/tools/test_rev_a_manufacturing_metadata.py'
(dest/test).write_text('''#!/usr/bin/env python3
"""Regression checks for revision-label clearance; native release source is read-only."""
import contextlib
import io
from pathlib import Path
import tempfile
import unittest

import validate_rev_a_manufacturing_metadata as validator


class RevisionLabelClearanceTests(unittest.TestCase):
    def check_fixture(self, x, y):
        original = validator.PCB
        text = original.read_text(encoding="utf-8")
        self.assertEqual(text.count("(at 180 142 0)"), 1)
        with tempfile.TemporaryDirectory(prefix="ayab-label-regression-") as temporary:
            fixture = Path(temporary) / "fixture.kicad_pcb"
            fixture.write_text(text.replace("(at 180 142 0)", f"(at {x} {y} 0)"), encoding="utf-8")
            try:
                validator.PCB = fixture
                with contextlib.redirect_stdout(io.StringIO()):
                    validator.main()
            finally:
                validator.PCB = original

    def test_release_label_passes(self):
        self.check_fixture(180, 142)

    def test_artwork_overlap_is_rejected(self):
        # This location crosses the AYAB artwork, which uses reference G***.
        with self.assertRaisesRegex(RuntimeError, "overlaps front footprint silkscreen"):
            self.check_fixture(150, 133)

    def test_previous_pad_overlap_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "overlaps front pad/mask clearance"):
            self.check_fixture(174, 161.2)


if __name__ == "__main__":
    unittest.main()
''',encoding='utf-8')
patch=''
for rel in [*changed,test]:
    a=(SRC/rel).read_bytes().decode('utf-8').splitlines(keepends=True) if (SRC/rel).exists() else []
    b=(dest/rel).read_bytes().decode('utf-8').splitlines(keepends=True)
    patch+='diff --git a/'+rel+' b/'+rel+'\n'
    if not a:patch+='new file mode 100644\n'
    patch+=''.join(difflib.unified_diff(a,b,fromfile='a/'+rel if a else '/dev/null',tofile='b/'+rel))
(RES/'remaining-repairs.patch').write_bytes(patch.encode('utf-8'))
data={'base_commit':COMMIT,'repair_time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'changed_tracked_files':changed,'added_file':test,'native_source_changed':False,'original_repository_modified':False,'commit_created':False,'scope':'Two current compatibility-note references corrected TP701 to TP703; validator now checks artwork footprints; regression tests added.'}
save('repair-summary.json',data)
save('repaired-source-file-hashes.json',{p.relative_to(dest).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.rglob('*') if p.is_file()})
print(json.dumps(data,indent=2))
