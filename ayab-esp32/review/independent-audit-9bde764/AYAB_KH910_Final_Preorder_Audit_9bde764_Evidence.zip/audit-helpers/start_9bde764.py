from pathlib import Path
import sys,json,hashlib,zipfile,shutil,re,datetime
WORK=Path.cwd()/'work';BASE=WORK/'preorder-audit-9bde764';BASE.mkdir(exist_ok=False)
OLD=WORK/'preorder-audit-00b3978';RES=BASE/'audit-results';RES.mkdir()
COMMIT='9bde764c6e157920af34ccd1063949ac5dcc5109'
for n in ['audit_helpers.py','run_live.py','redirect_report.py','independent_review.py','inspect_geometry.py','render_views.cjs','crop_views.cjs','extra_checks.py']:
 t=(OLD/n).read_text(encoding='utf-8')
 if n=='audit_helpers.py':t=t.replace("COMMIT='00b397811cd4ecf61d68ad1d0c13dd36463a22ea'","COMMIT='"+COMMIT+"'")
 if n=='extra_checks.py':
  t=t.replace("OLD=BASE.parent/'preorder-audit-032c31c'","OLD=BASE.parent/'preorder-audit-00b3978'")
  t=t.replace('minimum=47000*(1-.01-.0001*15)','minimum=47000*(1-.01-.0001*130)').replace('absolute 15 C element-temperature departure from 25 C','absolute 130 C element-temperature departure from 25 C, for -55 to +155 C rated range')
 if n=='run_live.py':
  t=t.replace("def execute(name,args):", "env['KICAD6_3DMODEL_DIR']=str(BASE/'standard-models')\nsave(f'kicad{major}/model-environment.json',{'KICAD6_3DMODEL_DIR':env['KICAD6_3DMODEL_DIR']})\n\ndef execute(name,args):")
  t+='\nif major==\'10\':\n    for name,layers in [(\'front\',\'F.Cu,F.SilkS,Edge.Cuts\'),(\'back\',\'B.Cu,B.SilkS,Edge.Cuts\')]:\n        execute(name,[cli,\'pcb\',\'export\',\'svg\',\'--mode-single\',\'--page-size-mode\',\'2\',\'--layers\',layers,\'-o\',dest/(name+\'.svg\'),pcb])\n    for side in [\'top\',\'bottom\']:\n        execute(\'render-\'+side,[cli,\'pcb\',\'render\',\'--side\',side,\'--width\',\'3600\',\'--height\',\'1000\',\'--zoom\',\'3\',\'-o\',dest/f\'render-{side}.png\',pcb])\n'
 (BASE/n).write_text(t,encoding='utf-8')
shutil.copytree(OLD/'standard-models',BASE/'standard-models')
prov=json.loads((OLD/'audit-results/standard-model-provenance.json').read_text());prov['value']=str(BASE/'standard-models');prov['reuse']='Same hash-verified official model from previous audit';(RES/'standard-model-provenance.json').write_text(json.dumps(prov,indent=2))
sys.path.insert(0,str(BASE));from audit_helpers import *
info={k:run(['git',*args],REPO) for k,args in {'status':['status','--short'],'branch':['branch','--show-current'],'head':['rev-parse','HEAD'],'remote':['remote','-v'],'remote_head':['ls-remote','origin','refs/heads/ayab-esp32-kh910-rev-a']}.items()}
assert info['head']['stdout'].strip()==COMMIT and info['remote_head']['stdout'].split()[0]==COMMIT
info['timestamp']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('source-identity.json',info)
untracked=run(['git','ls-files','--others','--exclude-standard'],REPO)['stdout'].splitlines();save('original-untracked-hashes.json',{p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in untracked if (REPO/p).is_file()})
archive=BASE/'git-source.zip';r=run(['git','archive','--format=zip','--output',archive,COMMIT],REPO);save('source-archive-command.json',r);assert r['exit']==0
package=Path(r'C:\Users\bjrem\Downloads\AYAB_KH910_Final_Closure_Audit_9bde764.zip')
with zipfile.ZipFile(package) as z,zipfile.ZipFile(archive) as g:
 names=z.namelist();assert len(names)==len(set(names));assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
 rows=[]
 for line in z.read('MANIFEST_SHA256.txt').decode('utf-8-sig').splitlines():
  m=re.fullmatch(r'([a-fA-F0-9]{64})\s+\*?(.+)',line)
  assert m,line
  rows.append({'path':m[2],'sha256':hashlib.sha256(z.read(m[2])).hexdigest(),'match':hashlib.sha256(z.read(m[2])).hexdigest()==m[1].lower()})
 assert all(r['match'] for r in rows)
 assert {r['path'] for r in rows}==set(names)-{'MANIFEST_SHA256.txt'}
 save('handoff-manifest-verification.json',{'archive_sha256':hashlib.sha256(package.read_bytes()).hexdigest(),'files_checked':len(rows),'rows':rows})
 compare=[{'path':n,'exact':z.read(n)==g.read(n),'equal_normalized_newlines':z.read(n).replace(b'\r\n',b'\n')==g.read(n).replace(b'\r\n',b'\n')} for n in names if n in g.namelist()]
 save('handoff-git-comparison.json',{'compared':len(compare),'extra_package_files':[n for n in names if n not in g.namelist()],'rows':compare})
 assert all(r['exact'] for r in compare)
 z.extractall(SRC);gitfiles=g.namelist()
shutil.copytree(SRC,BASE/'source-kicad10')
save('source-file-hashes.json',{p.relative_to(SRC).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in SRC.rglob('*') if p.is_file()})
forbidden={'.gbr','.gbl','.gtl','.gbs','.gts','.gbo','.gto','.drl','.xln','.pos','.ger','.gerber'}
save('tracked-content-scan.json',{'files':gitfiles,'fabrication_candidates':[n for n in gitfiles if Path(n).suffix.lower() in forbidden],'package_fabrication_candidates':[n for n in names if Path(n).suffix.lower() in forbidden],'native_boards':[n for n in names if n.endswith('.kicad_pcb')]})
for label,args in [('delta-from-prior',['diff','--stat','00b397811cd4ecf61d68ad1d0c13dd36463a22ea',COMMIT]),('delta-from-ci-source',['diff','--name-only','231ab3c9c348c4bb3880c5ed453855c066cb82e0',COMMIT]),('recent-lineage',['log','-5','--format=%H %s'])]:save(label+'.json',run(['git',*args],REPO))
native_inventory()
print(json.dumps({'commit':COMMIT,'package_files':len(names),'manifest_pass':len(rows),'git_compared':len(compare)},indent=2))
