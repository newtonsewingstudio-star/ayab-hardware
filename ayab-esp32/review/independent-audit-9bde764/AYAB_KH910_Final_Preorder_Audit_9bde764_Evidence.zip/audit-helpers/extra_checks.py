from audit_helpers import *
import collections,posixpath,xml.etree.ElementTree as ET,datetime
OLD=BASE.parent/'preorder-audit-00b3978'
pcb=parse(SRC/'ayab-esp32/ayab-esp32.kicad_pcb');old=parse(OLD/'source/ayab-esp32/ayab-esp32.kicad_pcb')
manifest=json.loads((RES/'source-file-hashes.json').read_text());paths=set(manifest)
models=[]
for f in children(pcb,'footprint'):
    for m in children(f,'model'):
        path=m[1]
        relative=posixpath.normpath(path.replace('${KIPRJMOD}','ayab-esp32')) if path.startswith('${KIPRJMOD}') else None
        models.append({'ref':props(f).get('Reference'),'raw':path,'normalized_path':relative,'exact_case_in_package':relative in paths if relative else None})
save('independent-model-paths.json',models)
semantic={}
for kind in ['segment','arc','via','zone','gr_line','gr_arc']:
    a=children(old,kind);b=children(pcb,kind);semantic[kind]={'old_count':len(a),'new_count':len(b),'identical':sorted(map(str,a))==sorted(map(str,b))}
# Preserve every footprint even when legacy serialized UUIDs are duplicated.
def fpkey(f):return (props(f).get('Reference'),tuple(child(f,'at')[1:]),f[1])
af={fpkey(f):f for f in children(old,'footprint')};bf={fpkey(f):f for f in children(pcb,'footprint')}
changed=[]
def strip_ids(x):
    if not isinstance(x,list):return x
    return [strip_ids(c) for c in x if not (isinstance(c,list) and c and c[0]=='uuid')]
for uid,f in bf.items():
    o=af.get(uid)
    if o is None or any(child(f,k)!=child(o,k) for k in ['at','layer']) or strip_ids(children(f,'pad'))!=strip_ids(children(o,'pad')):changed.append(props(f).get('Reference'))
semantic['footprint_geometry']={'count':len(bf),'new_keys':sorted(set(bf)-set(af)),'removed_keys':sorted(set(af)-set(bf)),'changed':changed}
uuids=collections.defaultdict(list)
for f in children(pcb,'footprint'):uuids[child(f,'uuid')[1]].append({'ref':props(f).get('Reference'),'at':child(f,'at')[1:]})
save('serialized-duplicate-footprint-uuids.json',{u:rows for u,rows in uuids.items() if len(rows)>1})
save('independent-geometry-delta.json',semantic)
def memberships(p):
    root=ET.parse(p).getroot()
    return {n.attrib['name']:sorted((x.attrib['ref'],x.attrib['pin']) for x in n.findall('node')) for n in root.findall('./nets/net')}
a=memberships(OLD/'audit-results/kicad9/live-netlist.xml');b=memberships(RES/'kicad9/live-netlist.xml')
save('netlist-delta-from-prior.json',{'old_nets':len(a),'new_nets':len(b),'identical':a==b,'differences':{k:[a.get(k),b.get(k)] for k in a.keys()|b.keys() if a.get(k)!=b.get(k)}})
refs={c.attrib['ref'] for c in ET.parse(RES/'kicad9/live-netlist.xml').getroot().findall('./components/comp')};fps={props(f).get('Reference'):f for f in children(pcb,'footprint')}
obsolete={'U702','U703','C703','C704',*(f'R{i}' for i in range(715,735))}
save('independent-cleanup-check.json',{'obsolete_schematic':sorted(refs&obsolete),'obsolete_pcb':sorted(set(fps)&obsolete),'R611_absent_both':'R611' not in refs and 'R611' not in fps,'physical_components':len(refs)})
lib={s[1]:s for s in children(parse(SRC/'ayab-library/ayab-lib.kicad_sym'),'symbol')};cached={}
for p in (SRC/'ayab-esp32').glob('*.kicad_sch'):
    for s in children(child(parse(p),'lib_symbols'),'symbol'):
        if s[1].startswith('ayab-lib:'):cached[s[1]]=s
def pins(s):return sorted([json.dumps([['hide','yes'] if x=='hide' else x for x in p]) for u in children(s,'symbol') for p in children(u,'pin')])
save('custom-symbol-pin-review.json',[{'symbol':n,'match':pins(s)==pins(lib[n.split(':',1)[1]])} for n,s in cached.items()])
text=(RES/'kicad10/drc-parity.rpt').read_text()
save('kicad10/parity-classification.json',{'types':dict(collections.Counter(re.findall(r'^\[([^]]+)\]',text,re.M))),'fields':dict(collections.Counter(re.findall(r"Field '([^']+)' differs",text))),'missing_fields':re.findall(r"Missing symbol field '([^']+)' in footprint[\s\S]*?Footprint ([^\n]+)",text)})
minimum=47000*(1-.01-.0001*130)
save('independent-current-bound.json',{'assumed_min_resistor_ohms':minimum,'assumption':'1% initial tolerance, 100 ppm/C over absolute 130 C element-temperature departure from 25 C, for -55 to +155 C rated range; ambient maximum alone does not establish element-temperature range','rows':[{'raw_V':v,'conditional_mA_node_3V6':(v-3.6)/47,'loose_mA_node_nonnegative':v/minimum*1000} for v in [12,15,40]]})
print(json.dumps({'model_references':len(models),'exact_local':sum(m['exact_case_in_package'] is True for m in models),'external':[m['raw'] for m in models if m['normalized_path'] is None],'geometry_delta':semantic,'netlist_identical':a==b},indent=2))
