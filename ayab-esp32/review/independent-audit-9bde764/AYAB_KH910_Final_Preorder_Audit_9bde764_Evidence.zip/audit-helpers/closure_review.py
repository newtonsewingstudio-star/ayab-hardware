from audit_helpers import *
import collections,copy
OLD=BASE.parent/'preorder-audit-00b3978'
old=parse(OLD/'source/ayab-esp32/ayab-esp32.kicad_pcb');pcb=parse(SRC/'ayab-esp32/ayab-esp32.kicad_pcb')
def walk(x,path=()):
    if not isinstance(x,list):return
    if x and x[0]=='uuid':yield (x[1],path)
    for i,c in enumerate(x):
        if isinstance(c,list):yield from walk(c,path+(str(x[0]),str(i)))
def clean(x):
    if not isinstance(x,list):return x
    return [clean(c) for c in x if not (isinstance(c,list) and c and c[0]=='uuid')]
def fpkey(f):return (props(f).get('Reference'),tuple(child(f,'at')[1:]),f[1])
oldfp={fpkey(f):f for f in children(old,'footprint')};newfp={fpkey(f):f for f in children(pcb,'footprint')}
geometry={'objects':len(newfp),'new_keys':sorted(set(newfp)-set(oldfp)),'removed_keys':sorted(set(oldfp)-set(newfp)),'changed_excluding_uuids':[str(k) for k,v in newfp.items() if k not in oldfp or clean(v)!=clean(oldfp[k])]}
roots=collections.defaultdict(list);allfp=collections.defaultdict(list)
changed_ids=[]
for f in children(pcb,'footprint'):
    ref=props(f).get('Reference');roots[child(f,'uuid')[1]].append(ref)
    for uid,path in walk(f):allfp[uid].append({'ref':ref,'object_path':path})
    k=fpkey(f)
    if k in oldfp and list(walk(f))!=list(walk(oldfp[k])):
        a=list(walk(oldfp[k]));b=list(walk(f));changed_ids.append({'ref':ref,'old_root':child(oldfp[k],'uuid')[1],'new_root':child(f,'uuid')[1],'changed_uuid_count':sum(u!=v for (u,p),(v,q) in zip(a,b)),'old_object_count':len(a),'new_object_count':len(b)})
raw=collections.defaultdict(list)
for uid,p in walk(pcb):raw[uid].append(p)
duplicates={u:p for u,p in raw.items() if len(p)>1}
normalpairs={}
for dim in children(pcb,'dimension'):
    u=child(dim,'uuid')[1:]
    label=child(dim,'gr_text');lu=child(label,'uuid')[1:]
    if u and lu==u:normalpairs[u[0]]={'parent':'dimension','embedded':'gr_text','same_parent_identity':True}
uuid_review={'footprint_roots':len(children(pcb,'footprint')),'unique_roots':len(roots),'root_duplicates':{u:r for u,r in roots.items() if len(r)>1},'footprint_tree_uuid_count':sum(map(len,allfp.values())),'unique_footprint_tree_uuids':len(allfp),'tree_duplicates':{u:r for u,r in allfp.items() if len(r)>1},'all_board_uuid_occurrences':sum(map(len,raw.values())),'raw_repeated_groups':duplicates,'dimension_parent_text_pairs':normalpairs,'unexplained_raw_repeats':{u:p for u,p in duplicates.items() if not (u in normalpairs and len(p)==2)},'changed_footprints':changed_ids}
save('independent-uuid-closure.json',uuid_review)
o=clean(old);n=clean(pcb)
for t in children(o,'gr_text'):
    if t[1]=='KH910 REV A 09/2026':child(t,'at')[1:3]=['180','142']
geometry['whole_board_equal_after_uuid_removal_and_declared_label_move']=o==n
geometry['old_label']=[t for t in children(old,'gr_text') if t[1]=='KH910 REV A 09/2026']
geometry['new_label']=[t for t in children(pcb,'gr_text') if t[1]=='KH910 REV A 09/2026']
save('independent-normalized-geometry-delta.json',geometry)
assert not uuid_review['tree_duplicates'] and not uuid_review['unexplained_raw_repeats']
assert geometry['whole_board_equal_after_uuid_removal_and_declared_label_move']
assert not geometry['changed_excluding_uuids']
print(json.dumps({'geometry':geometry,'uuid_summary':{k:v for k,v in uuid_review.items() if k not in ['raw_repeated_groups','changed_footprints']}},indent=2))
