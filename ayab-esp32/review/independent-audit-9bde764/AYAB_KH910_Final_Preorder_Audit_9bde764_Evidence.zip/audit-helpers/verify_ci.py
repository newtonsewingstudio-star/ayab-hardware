from audit_helpers import *
import urllib.request,datetime,concurrent.futures
api='https://api.github.com/repos/newtonsewingstudio-star/ayab-hardware'
def get(path,name):
    url=api+path
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Independent-KiCad-audit','Accept':'application/vnd.github+json'}),timeout=35) as r:data=json.load(r)
    save(name,{'url':url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'data':data});return data
supplied=json.loads((SRC/'ci-evidence/CI_RUNS.json').read_text())
def check(row):
    i=row['id'];r=get(f'/actions/runs/{i}',f'ci-run-{i}.json');jobs=get(f'/actions/runs/{i}/jobs?per_page=100',f'ci-jobs-{i}.json')
    return {'id':i,'name':r['name'],'head':r['head_sha'],'branch':r['head_branch'],'conclusion':r['conclusion'],'supplied_match':r['head_sha']==supplied['repair_sha'] and r['head_branch']==supplied['branch'] and r['conclusion']==row['conclusion'] and r['name']==row['name'],'jobs':jobs['jobs']}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:checks=list(pool.map(check,supplied['runs']))
runs=[];page=1
while True:
    data=get('/actions/runs?branch=ayab-esp32-kh910-rev-a&created=%3E%3D2026-09-11&per_page=100&page='+str(page),f'ci-sequence-page{page}.json');runs+=data['workflow_runs']
    if len(runs)>=data['total_count'] or len(data['workflow_runs'])<100:break
    page+=1
summary={'repair_commit':supplied['repair_sha'],'all_six_match':all(x['supplied_match'] for x in checks),'checked_runs':checks,'branch_run_count':len(runs),'fabrication_runs':[{'id':r['id'],'name':r['name'],'head':r['head_sha']} for r in runs if 'fabrication' in (r.get('name') or '').lower()]}
save('ci-verification-summary.json',summary)
assert summary['all_six_match']
print(json.dumps({'checks':[{k:v for k,v in x.items() if k!='jobs'} for x in checks],'branch_run_count':len(runs),'fabrication_runs':summary['fabrication_runs']},indent=2))
