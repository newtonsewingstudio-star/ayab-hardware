from audit_helpers import *
import xml.etree.ElementTree as ET, collections, math
pcb=parse(SRC/'ayab-esp32/ayab-esp32.kicad_pcb');fps={props(f).get('Reference'):f for f in children(pcb,'footprint')}
def loadnet(v):
    root=ET.parse(RES/f'kicad{v}/live-netlist.xml').getroot();comps={c.attrib['ref']:c for c in root.findall('./components/comp')};nets={};members={}
    for n in root.findall('./nets/net'):
        members[n.attrib['name']]=sorted((x.attrib['ref'],x.attrib['pin']) for x in n.findall('node'))
        for x in n.findall('node'):nets[x.attrib['ref'],x.attrib['pin']]=n.attrib['name']
    return root,comps,nets,members
root,comps,snets,members=loadnet(9);r10,c10,n10,m10=loadnet(10)
save('version-netlist-comparison.json',{'identical_memberships':members==m10,'changes':{k:[members.get(k),m10.get(k)] for k in members.keys()|m10.keys() if members.get(k)!=m10.get(k)}})
netnames={n[1]:n[2] for n in children(pcb,'net')}
bpins={}
for ref,f in fps.items():
    for p in children(f,'pad'):
        n=child(p,'net')[1:];bpins[ref,p[1]]=netnames.get(n[0],n[-1]) if n else ''
norm=lambda n:'' if n.startswith('unconnected-') else n.replace('{slash}','/')
parity=[{'ref':r,'pin':p,'schematic':snets.get((r,p),''),'pcb':n} for (r,p),n in bpins.items() if r in comps and norm(n)!=norm(snets.get((r,p),''))]
save('independent-all-pin-parity.json',{'differences':parity,'pins_checked':sum(r in comps for r,p in bpins),'missing_pcb_refs':sorted(set(comps)-set(fps)),'extra_physical_pcb_refs':[r for r,f in fps.items() if r not in comps and children(f,'pad')]})
sch_by_uuid={};cached={}
for path in (SRC/'ayab-esp32').glob('*.kicad_sch'):
    tree=parse(path)
    for s in children(tree,'symbol'):sch_by_uuid[child(s,'uuid')[1]]=(path.name,s)
    for s in children(child(tree,'lib_symbols'),'symbol'):cached[s[1]]=s
metadata=[];associations=[];dnps=[]
fields=['Value','Footprint','Datasheet','Description','Package','OEM','OEM PN','LCSC ID']
for ref,c in comps.items():
    if ref not in fps:continue
    f=fps[ref];uids=c.findtext('tstamps').split();uid=uids[0];sheet,s=sch_by_uuid[uid];sprop=props(s);bprop=props(f)
    expected_path=c.find('sheetpath').attrib['tstamps']+uid
    actual_path=child(f,'path')[1:]
    associations.append({'ref':ref,'sheet':sheet,'uuid':uids,'expected_path':expected_path,'actual_path':actual_path,'match':any(actual_path==[c.find('sheetpath').attrib['tstamps']+u] for u in uids)})
    for key in fields:
        sv=c.findtext('value') if key=='Value' else c.findtext('footprint') if key=='Footprint' else c.findtext('datasheet') if key=='Datasheet' else next((x.text for x in c.findall('./fields/field') if x.attrib['name']==key),'')
        bv=f[1] if key=='Footprint' else bprop.get(key,'')
        if (sv or '').strip('~')!=(bv or '').strip('~'):metadata.append({'ref':ref,'sheet':sheet,'field':key,'schematic':sv,'pcb':bv})
    sdnp=child(s,'dnp')[1:]==['yes'];bdnp='dnp' in child(f,'attr')
    dnps.append({'ref':ref,'sch_dnp':sdnp,'pcb_dnp':bdnp,'match':sdnp==bdnp})
save('native-associations.json',associations);save('independent-metadata-differences.json',metadata);save('dnp-comparison.json',dnps)
selection={'U201':{'5','6','7','8','21','22','25'},'J701':{'6','7'},'U701':{'15','16'},'U302':{'9'},'U303':{'9'},'U304':{'9'},'J401':{'9','10'},'J403':{'9','10'},'J406':{'9','10'}}
for ref in ['R215','R216','D205','D206','C206','Q805','Q806','R820','R821','R822','R209','R210','C603','C604','C605','R735','R736','R737','R738','D601','U403','TP701','TP702','TP703','R213','R214']:selection[ref]=None
trace=[]
for ref,pins in selection.items():
    f=fps[ref]
    for p in children(f,'pad'):
        if pins is not None and p[1] not in pins:continue
        trace.append({'ref':ref,'pin':p[1],'value':props(f).get('Value'),'schematic_net':snets.get((ref,p[1]),''),'pcb_net':bpins[ref,p[1]],'match':norm(snets.get((ref,p[1]),''))==norm(bpins[ref,p[1]]),'at':child(f,'at')[1:],'side':child(f,'layer')[1]})
save('critical-trace.json',trace)
ordering={}
for r in ['R820','R821','R822','R735','R736','R737','R738','D204','D601','D605','D606','U403','D205','D206']:
    c=comps[r];s=sch_by_uuid[c.findtext('tstamps').split()[0]][1]
    ordering[r]={'native_instance_properties':props(s),'live_schematic_fields':{x.attrib['name']:x.text for x in c.findall('./fields/field')},'live_value':c.findtext('value'),'pcb_properties':props(fps[r]),'library_id':child(s,'lib_id')[1]}
save('critical-ordering-review.json',ordering)
def numeric(vals):
    out=[]
    for v in vals:
        try:out.append(round(float(v),6))
        except (ValueError,TypeError):out.append(v)
    return out
def signature(f):
    fa=child(f,'at')[3:] or ['0'];angle=float(fa[0]);pads=[]
    for p in children(f,'pad'):
        at=child(p,'at')[1:];pa=float(at[2]) if len(at)>2 else 0
        d={'number':p[1],'type':p[2],'shape':p[3],'position':numeric(at[:2]),'orientation':round((pa-angle)%360,6)}
        for k in ['size','drill','layers','rect_delta','roundrect_rratio','chamfer_ratio','chamfer','solder_mask_margin','solder_paste_margin','solder_paste_margin_ratio']:
            d[k]=numeric(child(p,k)[1:])
        pads.append(d)
    return sorted(pads,key=lambda d:json.dumps(d,sort_keys=True))
custom=[]
for ref,f in fps.items():
    if ':' not in f[1]:continue
    lib,name=f[1].split(':',1)
    if lib not in ['Library','easyeda2kicad','Espressif']:continue
    p=SRC/'ayab-library'/f'{lib}.pretty'/f'{name}.kicad_mod'
    sf=signature(f);sl=signature(parse(p)) if p.exists() else None
    custom.append({'ref':ref,'id':f[1],'file':str(p.relative_to(SRC)),'exists':p.exists(),'side':child(f,'layer')[1],'match':sf==sl,'placed':sf,'pinned':sl})
save('independent-custom-pad-geometry.json',custom)
project=json.loads((SRC/'ayab-esp32/ayab-esp32.kicad_pro').read_text())
save('project-rules-and-stackup.json',{'rules':project['board']['design_settings']['rules'],'severities':project['board']['design_settings']['rule_severities'],'exclusions':project['board']['design_settings']['drc_exclusions'],'stackup':child(child(pcb,'setup'),'stackup'),'thickness':child(child(pcb,'general'),'thickness'),'copper_layers':[l for l in child(pcb,'layers')[1:] if l[1].endswith('.Cu')]})
labels=[{'text':t[1],'at':child(t,'at')[1:],'layer':child(t,'layer')[1:],'effects':child(t,'effects')} for t in children(pcb,'gr_text')]
save('board-labels.json',labels)
erc={}
for ver in [9,10]:
    t=(RES/f'kicad{ver}/erc.rpt').read_text();erc[str(ver)]={'counts':dict(collections.Counter(re.findall(r'^\[([^]]+)\]',t,re.M))),'symbols':dict(collections.Counter(re.findall(r"Symbol '([^']+)' doesn't match",t)))}
save('erc-warning-classification.json',erc)
def pin_signature(lib):
    return sorted([{'num':child(p,'number')[1],'name':child(p,'name')[1],'type':p[1],'at':child(p,'at')[1:],'length':child(p,'length')[1:]} for s in children(lib,'symbol') for p in children(s,'pin')],key=lambda x:x['num'])
libpath=BASE.parent/'independent-audit-647998e/kicad9-runtime/share/kicad/symbols/power.kicad_sym'
power={s[1]:s for s in children(parse(libpath),'symbol')};powers={}
for name in erc['9']['symbols']:
    cp=pin_signature(cached['power:'+name]);lp=pin_signature(power[name]);powers[name]={'cached':cp,'library':lp,'same_geometry_number_type':[{k:v for k,v in p.items() if k!='name'} for p in cp]==[{k:v for k,v in p.items() if k!='name'} for p in lp]}
save('power-symbol-warning-review.json',powers)
save('sense-and-thermal-calculations.json',{'divider_ratio':10/57,'rows':[{'raw_v':v,'unclamped_divider_v':v*10/57,'open_r216_current_ma_assuming_node_3v6':(v-3.6)/47,'open_r216_upper_bound_ma_node_nonnegative':v/47} for v in [12,15,40]],'coil_plus_logic_A':.25+4*.086,'margin_A':.65-.25-4*.086,'q805_p_w_at_065A':.65**2*.07,'q805_drop_v_at_065A':.65*.07})
print('All-pin exceptions',parity)
print('Association exceptions',[x for x in associations if not x['match']])
print('DNP exceptions',[x for x in dnps if not x['match']])
print('Metadata differences',metadata)
print('Custom geometries',len(custom),'mismatches',[(x['ref'],x['id']) for x in custom if not x['match']])
print('ERC',erc,'power signatures',all(x['same_geometry_number_type'] for x in powers.values()))
print('Version memberships same',members==m10)
