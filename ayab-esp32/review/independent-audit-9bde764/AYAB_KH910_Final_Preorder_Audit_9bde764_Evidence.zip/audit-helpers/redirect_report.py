"""Execute unmodified frozen script; redirect only its hardcoded report write."""
from pathlib import Path
import sys, runpy
script=Path(sys.argv[1]).resolve(); output=Path(sys.argv[2]).resolve()
names={'audit_rev_a_hall_pcb_parity.py':'KH910_REV_A_HALL_PCB_PARITY.md','audit_rev_a_kl_pcb_parity.py':'KH910_REV_A_KL_PCB_PARITY.md','audit_esp32_pinmap.py':'KH910_REV_A_CURRENT_PIN_AUDIT.md'}
expected=script.parents[1]/names[script.name]
original=Path.write_text
def redirected(self,data,*args,**kwargs):
    if self.resolve()!=expected: raise RuntimeError('Unexpected report write: '+str(self))
    print('AUDITOR_REPORT_REDIRECT',self,'->',output)
    return original(output,data,*args,**kwargs)
Path.write_text=redirected
sys.argv=[str(script)]
runpy.run_path(str(script),run_name='__main__')
