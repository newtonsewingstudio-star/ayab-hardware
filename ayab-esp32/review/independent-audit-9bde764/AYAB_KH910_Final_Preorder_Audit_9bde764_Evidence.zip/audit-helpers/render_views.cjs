const sharp=require('C:/Users/bjrem/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const fs=require('fs'),path=require('path');
const b=path.join(__dirname,'audit-results','kicad'+(process.argv[2]||'9'));
(async()=>{
for(const n of (process.argv[3]?process.argv[3].split(','):['front','back','front-outlines','back-outlines'])){
 let s=fs.readFileSync(path.join(b,n+'.svg'),'utf8');
 let m=s.match(/viewBox="([^"]+)/)[1].split(' ').map(Number);
 s=s.replace(/width="[^"]+" height="[^"]+"/,'width="6000px" height="'+Math.round(6000*m[3]/m[2])+'px"');
 await sharp(Buffer.from(s),{limitInputPixels:false}).flatten({background:'#ffffff'}).png().toFile(path.join(b,n+'.png'));
}
console.log('Rendered views');
})();
