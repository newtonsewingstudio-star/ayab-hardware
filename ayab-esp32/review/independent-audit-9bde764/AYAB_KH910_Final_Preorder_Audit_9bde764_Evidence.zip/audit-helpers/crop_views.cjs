const sharp=require('C:/Users/bjrem/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const path=require('path');const b=path.join(__dirname,'audit-results/kicad9');
(async()=>{for(const layer of ['front','back','front-outlines','back-outlines']){
for(const [name,left,width] of [['left',400,2000],['middle',2300,1700],['right',3900,1700]]){
await sharp(path.join(b,layer+'.png')).extract({left,top:470,width,height:950}).png().toFile(path.join(b,layer+'-'+name+'.png'));
}}})();
