from audit_helpers import *
import datetime,io
read=lambda n:json.loads((RES/n).read_text(encoding='utf-8'))
initial=read('source-file-hashes.json');verification={}
for name,src in [('kicad9',SRC),('kicad10',BASE/'source-kicad10')]:
    current={p.relative_to(src).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in src.rglob('*') if p.is_file()}
    verification[name]={'original_files':len(initial),'files':len(current),'changed':[p for p,h in initial.items() if current.get(p)!=h],'extra':sorted(set(current)-set(initial))}
old_untracked=read('original-untracked-hashes.json');untracked=run(['git','ls-files','--others','--exclude-standard'],REPO)
now={p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in untracked['stdout'].splitlines() if (REPO/p).is_file()}
verification['original_untracked']={'files':len(now),'unchanged':now==old_untracked}
for name,args in [('status',['git','status','--short']),('branch',['git','branch','--show-current']),('head',['git','rev-parse','HEAD']),('remote',['git','ls-remote','origin','refs/heads/ayab-esp32-kh910-rev-a'])]:verification[name]=run(args,REPO)
archive=Path(r'C:\Users\bjrem\Downloads\AYAB_KH910_Final_Closure_Audit_9bde764.zip')
verification['handoff_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();verification['handoff_unchanged']=verification['handoff_sha256']==read('handoff-manifest-verification.json')['archive_sha256']
src=BASE/'repaired-source';current={p.relative_to(src).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in src.rglob('*') if p.is_file()}
expected=read('repaired-source-file-hashes.json');assert current==expected
changed=[p for p,h in current.items() if p in initial and initial[p]!=h]
repair=read('repair-summary.json');assert set(changed)==set(repair['changed_tracked_files'])
verification['repaired_source']={'files':len(current),'hashes_match_after_tests':current==expected,'changed_original_files':changed,'added_files':sorted(set(current)-set(initial)),'all_native_files_unchanged':all(h==initial[p] for p,h in current.items() if Path(p).suffix in ['.kicad_pcb','.kicad_sch','.kicad_pro','.kicad_sym','.kicad_mod'])}
forbidden={'.gbr','.gbl','.gtl','.gbs','.gts','.gbo','.gto','.drl','.xln','.pos','.ger','.gerber'}
def zipscan(data,prefix=''):
    found=[]
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for n in z.namelist():
            if Path(n).suffix.lower() in forbidden:found.append(prefix+n)
            if n.lower().endswith('.zip'):found+=zipscan(z.read(n),prefix+n+'!/')
    return found
verification['recursive_handoff_fabrication_scan']=zipscan(archive.read_bytes())
verification['timestamp']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('final-source-integrity.json',verification)
assert all(not verification[v]['changed'] for v in ['kicad9','kicad10'])
assert verification['original_untracked']['unchanged'] and verification['handoff_unchanged']
assert verification['status']['stdout']==read('source-identity.json')['status']['stdout']
assert verification['head']['stdout'].strip()==COMMIT and verification['remote']['stdout'].startswith(COMMIT)
assert verification['repaired_source']['all_native_files_unchanged'] and not verification['recursive_handoff_fabrication_scan']
print(json.dumps(verification,indent=2))
