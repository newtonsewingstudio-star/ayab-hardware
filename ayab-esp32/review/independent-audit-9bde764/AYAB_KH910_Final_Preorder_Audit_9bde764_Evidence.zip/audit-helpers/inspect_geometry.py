from audit_helpers import *
import pcbnew, collections, math
b=pcbnew.LoadBoard(str(SRC/'ayab-esp32/ayab-esp32.kicad_pcb'));b.BuildConnectivity()
def pt(v): return [pcbnew.ToMM(v.x),pcbnew.ToMM(v.y)]
fps={f.GetReference():f for f in b.GetFootprints()}
inventory={r:{'value':f.GetValue(),'at':pt(f.GetPosition()),'angle':f.GetOrientationDegrees(),'layer':b.GetLayerName(f.GetLayer()),'pads':[{'number':p.GetNumber(),'at':pt(p.GetPosition()),'net':p.GetNetname(),'size':pt(p.GetSize()),'drill':pt(p.GetDrillSize())} for p in f.Pads()]} for r,f in fps.items()}
save('pcbnew9-geometry.json',inventory)
tracks=collections.defaultdict(list)
for t in b.GetTracks():
    item={'start':pt(t.GetStart()),'end':pt(t.GetEnd()),'width':pcbnew.ToMM(t.GetWidth(t.GetLayer()) if isinstance(t,pcbnew.PCB_VIA) else t.GetWidth()),'layer':b.GetLayerName(t.GetLayer()),'via':isinstance(t,pcbnew.PCB_VIA)}
    if item['via']:item['drill']=pcbnew.ToMM(t.GetDrillValue())
    tracks[t.GetNetname()].append(item)
save('pcbnew9-copper-inventory.json',tracks)
zones=[]
for z in b.Zones():
    p=z.Outline(); outlines=[]
    for i in range(p.OutlineCount()):
        chain=p.Outline(i);outlines.append([pt(chain.CPoint(j)) for j in range(chain.PointCount())])
    zones.append({'net':z.GetNetname(),'layers':str(z.GetLayerSet().FmtBin()),'rule_area':z.GetIsRuleArea(),'outlines':outlines,'filled':z.IsFilled(),'island_mode':str(z.GetIslandRemovalMode())})
save('pcbnew9-zones.json',zones)
print('Footprints',len(fps),'tracks/vias',sum(map(len,tracks.values())),'zones',len(zones))
for name in ['+12V','SOLENOID_12V_SW','GND','AYAB_SCL','/ESP32/AYAB_SCL']:
    ts=tracks.get(name,[]);print(name,'segments',len(ts),'width counts',dict(collections.Counter(t['width'] for t in ts if not t['via'])),'vias',sum(t['via'] for t in ts))
for r in ['U201','U403','R215','R216','D205','D206','C206','Q805','Q806','R820','R821','R822','C603','C604','C605','J701','U701']:
    print(r,json.dumps(inventory[r]))
