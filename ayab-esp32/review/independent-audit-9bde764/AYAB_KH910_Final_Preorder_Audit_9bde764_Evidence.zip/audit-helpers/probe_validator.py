from audit_helpers import *
import os
fixtures=BASE/'test-fixtures';fixtures.mkdir(exist_ok=True)
src=SRC/'ayab-esp32/ayab-esp32.kicad_pcb';txt=src.read_text(encoding='utf-8')
assert txt.count('(at 180 142 0)')==1
fixture=fixtures/'artwork-overlap.kicad_pcb';fixture.write_text(txt.replace('(at 180 142 0)','(at 150 133 0)'),encoding='utf-8')
validator=SRC/'ayab-esp32/tools/validate_rev_a_manufacturing_metadata.py'
code='import importlib.util;from pathlib import Path;s=importlib.util.spec_from_file_location("validator",'+repr(str(validator))+');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.PCB=Path('+repr(str(fixture))+');m.main()'
py=BASE.parent/'independent-audit-647998e/kicad9-runtime/bin/python.exe'
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
r=run([py,'-c',code],BASE,env=env);save('validator-artwork-before-repair.json',r)
print(json.dumps(r,indent=2))
