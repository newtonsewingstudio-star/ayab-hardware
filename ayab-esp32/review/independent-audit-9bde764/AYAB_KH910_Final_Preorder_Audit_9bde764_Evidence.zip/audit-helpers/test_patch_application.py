from pathlib import Path
import sys,json,shutil,hashlib
base=Path.cwd()/'work/preorder-audit-9bde764';sys.path.insert(0,str(base));from audit_helpers import *
info=json.loads((RES/'repair-summary.json').read_text());dest=BASE/'patch-apply-check';dest.mkdir(exist_ok=True)
# Materialize only the three patch inputs from the unchanged checkout.
for rel in info['changed_tracked_files']:
 p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REPO/rel,p)
r=run(['git','apply',RES/'remaining-repairs.patch'],dest);save('repair-patch-application-test.json',r);assert r['exit']==0,r
for rel in [*info['changed_tracked_files'],info['added_file']]:
 assert (dest/rel).read_bytes().replace(b'\r\n',b'\n')==(BASE/'repaired-source'/rel).read_bytes().replace(b'\r\n',b'\n'),rel
save('repair-patch-equivalence.json',{'applied_only_to_disposable_directory':str(dest),'four_repaired_files_match_after_CRLF_normalization':True})
print('Patch applies and reconstructs all four repaired files')
