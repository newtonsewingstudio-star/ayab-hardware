from audit_helpers import *
import os
dest=BASE/'repaired-source';py=BASE.parent/'independent-audit-647998e/kicad9-runtime/bin/python.exe'
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONIOENCODING']='utf-8'
for name,args in [('repaired-manufacturing-validator',[py,'ayab-esp32/tools/validate_rev_a_manufacturing_metadata.py']),('repair-regression-tests',[py,'ayab-esp32/tools/test_rev_a_manufacturing_metadata.py','-v'])]:
    r=run(args,dest,env=env);save(name+'.json',r);print(name,r['exit'],r['stdout'],r['stderr']);assert r['exit']==0
r=run(['git','apply','--check',RES/'remaining-repairs.patch'],REPO);save('repair-patch-check.json',r);print('Patch applies to original unchanged checkout',r['exit']);assert r['exit']==0
