from pathlib import Path
base=Path.cwd()/'work/preorder-audit-9bde764'
old=(base.parent/'preorder-audit-00b3978/report-main.md').read_text(encoding='utf-8')
def section(start,end):return old[old.index(start):old.index(end)]
head='''# AYAB KH910 Rev A — Final independent audit and repairs

**Verdict: PASS — suitable for ordering one controlled, unassembled prototype PCB in the documented four-layer/M2 configuration. No unresolved pre-order CAD condition was found after this audit's two small repairs. Physical qualification is still required before machine installation or solenoid operation.**

Reviewed repository: [newtonsewingstudio-star/ayab-hardware](https://github.com/newtonsewingstudio-star/ayab-hardware). Branch: `ayab-esp32-kh910-rev-a`. Packaged/current remote head: **9bde764c6e157920af34ccd1063949ac5dcc5109**. Underlying CAD repair commit: **231ab3c9c348c4bb3880c5ed453855c066cb82e0**. Baseline: **00b397811cd4ecf61d68ad1d0c13dd36463a22ea**. Audit date: 11 September 2026.

The two previous P2 conditions are closed: the revision marking is clear, and all footprint-tree object identities are unique. Fresh KiCad 9.0.9 checks show **0 DRC violations, 0 unconnected pads, 0 footprint errors and 0 schematic-parity issues**. ERC has **0 errors**, with 78 classified standard-power-library warnings. All nine repository validators pass. Independent comparisons verify 670 numbered PCB pins, 193 native schematic associations, all 11 required DNP decisions and all 23 custom-footprint instances.

Two additional P3 issues were found and repaired in the delivered isolated source: the clearance validator omitted artwork footprints, and two current compatibility documents named the wrong test point. Three regression tests pass. **No PCB, schematic, library, project setting, component value, routing or purchasing field required alteration.** The delivered source is the reviewed commit's selected source content plus these local script/document/test repairs; it is not a newly committed or CI-tested Git revision.

## 1. Authorization, scope and source integrity

The user's latest instruction authorizes auditing and repairing remaining issues. The package's handoff and stored reports were treated as evidence, not instructions or proof. Source inspection, native checks, independent comparisons and repair verification were carried out locally. No commit, push, order or workflow was initiated. No fabrication files were generated.

The original ZIP contains 318 files, and all **317 entries in its manifest pass**. Its SHA-256 is:

```text
b2d87d5c008ee1a2fa3f6d835ec32999c834e26781ea21fe2cb31b41c8e650c3
```

All **310 packaged Git-tracked paths match a fresh Git archive byte for byte**. A further comparison directly against raw Git objects avoids confusing archive conversion with Git storage: **18 files are byte-identical to their raw Git objects; all 310 match after CRLF/LF normalization**. The difference in the other 292 files is solely newline representation, including the native KiCad text files. Thus the package matches the committed source content, but this report does not falsely call every package byte identical to its raw Git blob. The eight additional package files contain handoff, manifest, prior-audit, diff and CI evidence.

Local HEAD and the live remote agree on the full 9bde764 hash. The tracked original working tree remains clean. These three pre-existing untracked entries were left in place, and all 18 underlying file hashes remain unchanged:

```text
?? ayab-esp32/tools/__pycache__/
?? render-34512445704/
?? work-pcbnew-api.log
```

Separate disposable copies held KiCad 9 and KiCad 10 input. All 318 original files in each copy remain byte-unchanged. KiCad 10 added only its local `.kicad_prl` preference file. It did not save a migrated PCB or schematic. The original supplied ZIP is unchanged.

There is one AYAB-ESP32 PCB and eight schematic sheets including the root; no daughterboard. A recursive scan of the handoff, including its nested prior-audit archive, found no Gerber/drill/placement output. The full historical repository still contains ten unrelated AYAB-interface Gerbers, listed in the evidence; those are excluded from both delivered ZIPs.

## 2. Environment and fresh native checks

Primary: **KiCad 9.0.9**, official Windows runtime, Python 3.11.5, x64. Supplemental: **KiCad 10.0.6**, Windows installation, Python 3.11.5, x64. Host: Windows 10 Home 10.0.19045 x64. Auxiliary evidence processing used Python 3.12.14 and Node/Sharp.

Each version used separate configuration and temporary directories, configured standard symbol/footprint tables and its own native source copy. The project uses repository-pinned custom libraries. U701's standard 3D model was supplied through an external legacy-variable override using the same hash-verified official model as the previous audit; every 3D render in this audit includes that dependency. Exact paths, commands, environment settings, exit codes and full console outputs are preserved in the appendix and evidence.

The primary run reproduces the KiCad 9 release commands and acceptance criteria on Windows. It is not a byte-for-byte recreation of the Ubuntu CI runner. CI's dependency script selects the KiCad 9 release series; its exact installed patch version was not independently established from an installation log. KiCad 10 results remain supplemental.

| Native check | KiCad 9.0.9 — primary | KiCad 10.0.6 — supplemental |
|---|---|---|
| PCB DRC with violation-sensitive exit | Exit 0; 0 violations, 0 unconnected, 0 footprint errors | Exit 0; 0 violations, 0 unconnected, 0 footprint errors |
| Full schematic parity | Exit 0; console explicitly reports 0 parity issues | Exit 5; 187 field-mismatch warnings, classified below |
| ERC with violation-sensitive exit | Exit 5; 0 errors, 78 library warnings | Exit 0; 0 errors, 0 warnings |
| Fresh electrical netlist | Exit 0; no annotation warning | Exit 0; no annotation warning; identical net memberships |
| Front/back 2D and 3D exports | Exit 0 | Exit 0 |

KiCad 9's 78 ERC warnings are exclusively `lib_symbol_mismatch`: **43 GND, 19 +3V3, 10 +5V and 6 +12V**. Independent comparison of cached and standard symbols found the same pin numbers, types, positions and lengths; power pin-name metadata differs. These are not missing custom symbols or established electrical faults. They explain the warning-sensitive ERC exit 5. Some KiCad 9 exports emit a nonfatal Fontconfig message; the exports complete.

KiCad 10's 187 parity diagnostics are **164 Description differences, 22 Datasheet differences and one missing Package field on TP703 at (145,159)**. The previous duplicated-ID source reported TP701; the current fresh report identifies TP703. These are local metadata diagnostics, not disconnected copper or wrong component values. Broader independent comparison finds 183 Description and 22 Datasheet value differences; its scope differs from KiCad's report. No value, manufacturer, order-code, DNP or electrical-net mismatch was found. The inherited noncritical metadata was retained, with accurate compatibility documentation.

KiCad 10 uses tighter SVG page framing and a greener default 3D material appearance than KiCad 9. Both render the same component geometry and clear revision marking. No pixel-equivalence or actual manufactured solder-mask-color claim is made.

## 3. Closure of the previous findings

| Finding | Result | Independent evidence |
|---|---|---|
| N1 wrong diode purchasing identities | PASS, maintained | D204/D605/D606 remain SS54, C22452, MDD, SMA in active schematic and PCB. |
| N2 six stale schematic paths | PASS, maintained | R213/R214/R735–R738 match active instances; all 193 associations match. |
| N3 copper assumptions | PASS, maintained | 35 µm outer / 17.5 µm inner; modeled 1.6062 mm board. |
| N4 revision marking overlap | **CLOSED** | Label at (180,142), with clear pads, mask openings, outlines and artwork; independent geometry plus fresh populated render. |
| N5 conditional clamp-current wording | PASS, maintained | Conditional 3.6 V-node values remain separate from loose current bounds and GPIO safety claims. |
| N6 local model paths | PASS, maintained | All 165 local references match exact archive filename case; one standard model configured externally. |
| N7 critical metadata | PASS, maintained | Critical rectifier/bridge/clamp/isolation parts retain the corrected identities and purchasing fields. |
| N8 fabrication-free wording | PASS, maintained | Release package distinguished from historical unrelated Git Gerbers. |
| N9 annotation | PASS, maintained | No annotation warning in either fresh ERC/netlist export. |
| N10 mounting hardware | PASS, maintained | Six M2 values match 2.2 mm drills; physical chassis fit remains unmeasured. |
| N11 duplicated object IDs | **CLOSED** | 237 distinct footprint roots and 6,053 distinct footprint-tree UUIDs; no copied root or nested ID remains. |
| N12 supplemental metadata wording | **CLOSED in delivered repair** | Field types were described correctly, but the current affected reference is TP703. Two current source notes corrected. |
| N13 resistor-temperature assumption | **CLOSED** | Full -55 to +155 °C rated range used, maximum 130 °C departure; 45.919k minimum recalculated and manufacturer data checked. |

The complete revision text bounding box is **X=172.856428–187.143573, Y=141.303850–142.696150 mm** on front silk. An independent scan included actual mask expansion, 176 front courtyards derived from their graphic primitives, front body outlines, visible fields and artwork; 3,259 obstacle boxes were considered. No obstacle intersects the box plus a 0.20 mm margin. The nearest bounding-box obstacle is artwork, approximately **1.350677 mm** away. Expanded corners lie inside the native board outline; the actual location is visibly clear of the central slot and outer edge. Dimensions of vendor hardware still require physical confirmation.

The eight repaired footprint trees are R820/R821/R822/TP703/Q805/Q806/C206/D206. Four remaining repeated raw IDs each belong to a dimension and its own embedded dimension label. Their parent-child relationships are verified; they are not shared between distinct footprint objects. The native KiCad 9 loaded board also has 237 unique footprint root IDs.

After removing only object UUID fields and accounting for the declared label move, **the entire parsed PCB equals the previous audited board**. All 237 footprint geometries, placements, pads, layers, nets, schematic paths and DNP flags are preserved. All 1,734 straight track segments, 12 curved track segments, 252 vias, five zones, ten outline lines and ten outline arcs remain unchanged. Both fresh netlists retain the same 152 net memberships as 00b3978.

## 4. Original F1–F12 regression review

| Item | Fresh independent conclusion |
|---|---|
| F1 gate resistor identities | R820/R822 100k, C25803, 0603WAF1003T5E; R821 10k, C25804, 0603WAF1002T5E. Schematic/PCB agree. |
| F2 Hall dividers | R735–R738 remain 10k, C25804, 0603WAF1002T5E in both representations. |
| F3 GPIO3 isolation | U201.7 no-connect; J701.6/U701.16 and J701.7/U701.15 local channels retained. GPIO4 sense and GPIO17/18 end-stop paths intact. |
| F4 switched capacitors | C603/C604/C605 connect SOLENOID_12V_SW to GND. |
| F5 DNP | All eleven specified resistors agree: R501, R701–R707, R709, R711, R713. |
| F6 native parity | Direct KiCad 9 parity completes with zero issues; 193 associations and 670 numbered pins agree independently. |
| F7 I²C | R209/R210 remain 5k1 pull-ups from +3V3 to AYAB_SCL/AYAB_SDA. |
| F8 fault tree | Correct default-OFF topology with disclosed unsafe single faults; detailed review below. |
| F9 custom libraries/manufacturing | 18 custom footprint IDs / 23 instances match pinned full pad signatures; controlled rules and stackup unchanged. |
| F10 cleanup and labels | Active comparator remnants and R611 absent; Hall/K/L remain intact; old badges absent; required labels visible. Revision label now clear. |
| F11 current limits | 0.65 A total bridge average, ≤40 °C ambient, 0.25 A logic reserve, ≤four nominal 86 mA coils pending qualification. |
| F12 critical ordering metadata | D204/D601/D605/D606/U403/D205/D206 identities, descriptions, datasheets, packages and DNP reviewed; no material mismatch found. |

All 34 cached custom-symbol pin definitions agree with the pinned symbol library after normalizing equivalent hidden-pin syntax. The unused cached LM393 definition does not represent an active comparator. U702/U703, C703/C704, R715–R734 and R611 remain absent from active native components.

'''
machine=section('## 6. Machine-sense','## 7. Solenoid gate').replace('## 6.','## 5.',1)
machine=machine.replace('R215=46.4595k','R215=45.919k').replace('0.2583 mA','0.2613 mA').replace('0.3229 mA','0.3267 mA').replace('0.8610 mA','0.8711 mA')
a=machine.index('The arithmetic is correct:');b=machine.index('Residual limitations remain:')
machine=machine[:a]+'''The updated arithmetic uses `47000 × (1 − 0.01 − 100e-6 × 130) = 45919 ohms`. The 0603, 47k part's -55 to +155 °C operating range, ±1% tolerance and ±100 ppm/°C TCR are supported by the [UNI-ROYAL manufacturer datasheet, ratings and TCR tables](https://datasheet.lcsc.com/datasheet/pdf/0a975aaa49b7c97f38a963127be4a823.pdf?productCode=C25819). Maximum departure from 25 °C is 130 °C. This removes the previous unsupported inference from ambient maximum to element temperature. The bounds still assume a nonnegative sense node and the resistor within its applicable specifications; they are not a guarantee after damage, aging, overload or improper assembly. Temperature-range coverage does not waive power derating or certify the clamp voltage.\n\n'''+machine[b:]
gate=section('## 7. Solenoid gate','## 8. Visual').replace('## 7.','## 6.',1)
tail='''## 7. Visual, mechanical and manufacturing review

Fresh front/back copper/silk views, top/bottom populated 3D renders, body/courtyard views and inner layers were reviewed. The solenoid gate area, rear clamp cluster, connectors, high-current paths and revision marking show no newly established pre-order body/copper/connector obstruction. `SOLENOID GATE`, `TP703 SW`, `D205 K=3V3` and `D206 A=GND` are legible and correctly oriented. The revision date is clear of pads and populated bodies. Legacy silk over insulated copper is not itself an exposed-pad overlap.

The four-layer board remains nominal 1.6 mm, with modeled finished thickness 1.6062 mm, 35 µm outer copper, 17.5 µm inner copper and 1.0604 mm core. The approximate outline centerline extent is 285.122 × 48.102 mm; the rounded central slot is approximately 3.8 × 10.425 mm. Six grounded mounting holes remain 2.2 mm and require M2 hardware. No hole or connector was resized during this audit.

Project minima remain: 0.10 mm clearance, 0.10 mm track width, 0.25 mm copper-to-edge, 0.20 mm through-hole drill, 0.05 mm via annulus, 0.30 mm via diameter and 0.25 mm hole-to-hole clearance. DRC exclusions are empty. Some silk/courtyard/library diagnostic categories are ignored, so a clean DRC alone does not prove readable marking or physical clearance. Independent geometry and visual checks supplement it.

All custom placed pads were compared against the pinned files, preserving duplicate pad numbers and checking position, orientation, size, shape, layers, drill and explicit mask/paste/chamfer/round-rectangle parameters. All 23 instances match. All 165 local 3D paths resolve with exact case. U701's `${KICAD6_3DMODEL_DIR}/Package_SO.3dshapes/TSSOP-24_4.4x7.8mm_P0.65mm.wrl` uses an externally configured, hash-verified [official KiCad model](https://gitlab.com/kicad/libraries/kicad-packages3D/-/tree/3a3cad1c1a74b408e66a1ce8333eef16a6d7f3c4/Package_SO.3dshapes). No source path was changed to suit this computer.

Rendered models cannot establish actual connector mating force, harness access, vendor body tolerances, clamp solderability, standoff insulation or chassis fit. Those remain physical gates.

## 8. Issues found and repaired during this audit

No unresolved P0/P1/P2 finding was established. These two P3 issues are closed in the delivered isolated repair:

| Finding | Evidence and location | Repair and verification |
|---|---|---|
| N12 follow-up: wrong reference in compatibility notes | Current KiCad 10 report names **TP703**, front at **(145,159)**, net **SOLENOID_12V_SW**, for the missing Package field. Two current documents still named TP701. | Corrected the two current closure documents to TP703. The earlier immutable audit and supplied handoff remain original evidence. No purchasing field or footprint changed. |
| N14: label validator skips artwork | `validate_rev_a_manufacturing_metadata.py` filtered `G***` artwork out of its silk-obstacle loop. A disposable fixture moving the revision text to **(150,133)** over AYAB artwork incorrectly returned `REVISION_LABEL_CLEARANCE_OK`. This is a checker gap, not a defect at the actual (180,142) label location. | Changed the silk/courtyard loop to inspect all footprint objects, retaining the deliberate duplicate-reference exception for artwork elsewhere. Added three regression cases: actual release label passes, AYAB artwork overlap is rejected, old R713/R714 pad overlap is rejected. All three pass. |

The repaired source contains **three modified tracked files and one added test file**. The PCB, all eight schematics, project and pinned libraries remain byte-identical to the audited package. The native KiCad results therefore apply to the repaired source's identical CAD input; only the changed validator and its regression tests required a new execution. Both pass. Repeated native board loads in the tests emit harmless duplicate image-handler notices; assertions still complete successfully.

The supplied patch is checked against the original checkout without applying it there. The source ZIP contains the 310 selected tracked source files with these repairs, plus the new test. The repair manifest identifies the modified files and base commit; no new Git hash is invented. Local repairs have not been pushed or run in remote CI.

## 9. Repository validators and limits

All nine source validators returned exit 0 on the frozen package. The modified manufacturing validator also returns exit 0 on the repaired source.

| Validator | Fresh evidence | Limit |
|---|---|---|
| audit_esp32_pinmap.py | 39 GPIOs; zero target-function mismatches | Does not establish actual firmware behavior. |
| audit_rev_a_hall_pcb_parity.py | 0/24 obsolete parts; 4/4 replacement dividers | Inventory alone is not full electrical proof. |
| audit_rev_a_kl_pcb_parity.py | K/L pad/net inventory completed | Supplemented by independent complete pin comparison. |
| audit_rev_a_power_pcb_parity.py | Fresh report PASS | Targets selected power circuits. |
| audit_rev_a_prototype_pcb_parity.py | `PROTOTYPE_PCB_PARITY_OK` | Presence/value checks are not a physical test. |
| audit_rev_a_solenoid_gate_source.py | `SOLENOID_GATE_SOURCE_AUDIT_OK` | Static topology/metadata, not timing/thermal qualification. |
| validate_rev_a_machine_sense_protection.py | `MACHINE_SENSE_PROTECTION_TOPOLOGY_OK` | Checks selected topology and conditional bounds, not surge immunity. |
| validate_rev_a_solenoid_failsafe_pcb.py | `SOLENOID_FAILSAFE_TOPOLOGY_OK` | No energized fault-injection evidence. |
| validate_rev_a_manufacturing_metadata.py | `MANUFACTURING_METADATA_OK`, ORDERING_REFS 9, DNP_REFS 11, PINNED_FOOTPRINT_IDS 18, PINNED_FOOTPRINT_INSTANCES 23, CONTROLLED_BOARD_RULES 5, CONTROLLED_ASSEMBLY_LABELS 5, FOOTPRINT_TREE_UUIDS_UNIQUE 6053, `REVISION_LABEL_CLEARANCE_OK` | Artwork gap repaired. Its pad dictionary and approximate clearances remain narrower than an independent full pad/visual review. |

Three validators normally write review files inside the project; an external wrapper redirected only their report destinations. Validator logic was inspected and executed without treating its output as sole proof. No repair/generation script from the handoff was blindly executed.

## 10. Independent CI verification

Public GitHub API responses independently confirm all six supplied runs succeeded at repair commit **231ab3c9c348c4bb3880c5ed453855c066cb82e0**, on the correct repository and branch:

- [Hardware Check — 34640744875](https://github.com/newtonsewingstudio-star/ayab-hardware/actions/runs/34640744875)
- [Hall PCB Parity — 34640744863](https://github.com/newtonsewingstudio-star/ayab-hardware/actions/runs/34640744863)
- [Machine Sense Protection — 34640744798](https://github.com/newtonsewingstudio-star/ayab-hardware/actions/runs/34640744798)
- [Rev A Patch — 34640744834](https://github.com/newtonsewingstudio-star/ayab-hardware/actions/runs/34640744834)
- [Prototype Power PCB Parity — 34640744862](https://github.com/newtonsewingstudio-star/ayab-hardware/actions/runs/34640744862)
- [Solenoid Gate Validation — 34640744812](https://github.com/newtonsewingstudio-star/ayab-hardware/actions/runs/34640744812)

The Hardware Check job confirms successful KiCad installation, DRC/unconnected/footprint/full-parity gate, ERC error gate, and frozen audits including manufacturing metadata. Installation ran 19:47:45–19:48:47 UTC; DRC 19:48:47–19:48:50; ERC 19:48:50–19:48:51. The subsequent head 9bde764 changes only six stored image/SVG/DRC evidence files relative to that repair commit. Native sources, libraries and validators are unchanged between the two commits.

The independently retrieved sequence contains **69 branch runs for 11 September through query time, with no fabrication-named workflow run**. No workflow was triggered by this audit. The six remote successes cover the supplied source lineage; the small additional repairs in this deliverable are verified locally and are not claimed to have remote CI approval.

## 11. Post-assembly gates — NEEDS PHYSICAL TEST

These tests remain unperformed. They do not block ordering the first bare PCB, but they block machine installation or operational solenoid use:

1. Inspect actual part numbers, polarity, bridge custom mapping, clamp wetting, MOSFET orientation and all eleven DNP positions. Check pull-resistor continuity and absence of a raw-to-switched short before power.
2. Dry-fit M2 mounting hardware, slot, connectors, harnesses, antenna recess, underside components and insulated standoffs. Stop if the real chassis requires incompatible hardware.
3. With a current-limited supply and no solenoids, scope USB-only, machine-only, combined-power insertion sequences, reset, boot, watchdog reset and brownout. Check rail pulses, capacitor discharge and USB/machine back-feed.
4. Measure GPIO4 divider voltage, real supply peaks, ADC calibration and clamp/reference behavior. The 40 V arithmetic is not a certified surge test.
5. Use dummy loads within 0.65 A total bridge average and ≤40 °C ambient; reserve 0.25 A for logic until measured and allow no more than four measured ~86 mA coils' equivalent load. Measure bridge, regulator, MOSFET, trace and via temperatures, inrush/PWM peaks and voltage drops.
6. Confirm actual firmware mapping, default-low/released GPIO21, watchdog behavior, fresh machine-sense reading after reset and coil/current limits. Hardware stuck-high faults remain outside software recovery.

No physical test is represented as passed. No redundancy, safety rating, surge certification or energized operational readiness is inferred from a clean CAD audit.

## 12. Deliverables

The Markdown report, separate evidence ZIP, repaired-source ZIP and Git patch are stored outside the original repository. Both ZIPs have internal SHA-256 manifests; an external checksum file covers all delivered artifacts. The evidence archive excludes native source and negative-test fixture PCBs. The source archive excludes prior-audit ZIPs, handoff claims and unrelated legacy fabrication files.

**No Gerbers, drill files, placement files, BOMs, fabrication archives or other manufacturing outputs were generated. The original repository and supplied ZIP remain unchanged; the documented repairs exist only in the delivered isolated source.**
'''
(base/'report-main.md').write_text(head+machine+gate+tail,encoding='utf-8')
print('Report body words',len((head+machine+gate+tail).split()))
