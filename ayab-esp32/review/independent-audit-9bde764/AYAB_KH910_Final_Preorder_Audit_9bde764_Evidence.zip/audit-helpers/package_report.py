from audit_helpers import *
import shutil
OUT=BASE.parent.parent/'outputs';OUT.mkdir(exist_ok=True)
name='AYAB_KH910_Final_Preorder_Audit_9bde764'
read=lambda n:json.loads((RES/n).read_text(encoding='utf-8'))
integrity=read('final-source-integrity.json')
assert all(not integrity[v]['changed'] for v in ['kicad9','kicad10'])
assert integrity['original_untracked']['unchanged'] and integrity['handoff_unchanged']
assert integrity['remote']['stdout'].startswith(COMMIT)
assert integrity['repaired_source']['all_native_files_unchanged']
assert not read('independent-all-pin-parity.json')['differences']
assert all(x['match'] for x in read('native-associations.json'))
assert all(x['match'] for x in read('independent-custom-pad-geometry.json'))
assert all(x['match'] for x in read('custom-symbol-pin-review.json'))
assert all(x['match'] for x in read('dnp-comparison.json'))
assert not read('independent-uuid-closure.json')['tree_duplicates']
assert not read('independent-label-clearance.json')['overlaps_or_margin_hits']
assert read('independent-normalized-geometry-delta.json')['whole_board_equal_after_uuid_removal_and_declared_label_move']
assert read('repair-regression-tests.json')['exit']==0 and read('repaired-manufacturing-validator.json')['exit']==0
assert read('repair-patch-check.json')['exit']==0 and read('repair-patch-equivalence.json')['four_repaired_files_match_after_CRLF_normalization']
assert read('ci-verification-summary.json')['all_six_match']
body=(BASE/'report-main.md').read_text(encoding='utf-8')
body+='\n\n## Appendix A. Identity, timestamps and exact native input hashes\n\n'
body+=f"Initial check: {read('source-identity.json')['timestamp']}. Final integrity check: {integrity['timestamp']}.\n\n"
body+='Hashes below identify the exact packaged native inputs, also preserved unchanged in repaired source. Raw Git blob comparisons with newline distinctions are separately recorded in `raw-git-blob-comparison.json`.\n\n| Native input | SHA-256 |\n|---|---|\n'
for p,h in read('source-file-hashes.json').items():
    if p.startswith('ayab-esp32/') and Path(p).suffix in ['.kicad_pcb','.kicad_sch','.kicad_pro']:body+=f'| `{p}` | `{h}` |\n'
body+='\nHistorical fabrication files in the full repository, excluded from both deliverables:\n\n'
for p in read('tracked-content-scan.json')['fabrication_candidates']:body+=f'- `{p}`\n'

body+='\n## Appendix B. Object identity repairs and native associations\n\nAll 193 active schematic associations match their PCB paths. All 237 loaded footprint roots and 6,053 serialized footprint-tree IDs are unique. The upstream repair changed these eight footprint trees, preserving every non-UUID field:\n\n| Reference | Current root UUID | Changed IDs |\n|---|---|---:|\n'
for r in read('independent-uuid-closure.json')['changed_footprints']:body+=f"| {r['ref']} | `{r['new_root']}` | {r['changed_uuid_count']} |\n"
body+='\nThe four remaining repeated raw IDs each connect a dimension to its own embedded label. Exact parent paths and full association records are in the evidence.\n\n'

body+='\n## Appendix C. Independent critical pad trace\n\nAll listed schematic nets match the native PCB. Hierarchical prefixes are retained. Coordinates are footprint origins; absolute pad positions are in `pcbnew9-geometry.json`.\n\n| Reference.pin | Value | Side / origin (mm) | Schematic and PCB net |\n|---|---|---|---|\n'
for x in read('critical-trace.json'):body+=f"| {x['ref']}.{x['pin']} | {x['value']} | {x['side']}: {', '.join(x['at'][:2])} | `{x['pcb_net']}` |\n"

body+='\n## Appendix D. Critical purchasing metadata\n\nThese read-only extracts are evidence, not a BOM. Active references come from the fresh schematic netlist.\n\n'
ordering=read('critical-ordering-review.json')
def clean(v):return str(v or '(blank)').replace('|','\\|').replace('\n',' ')
for ref in ['D204','D601','D605','D606','U403','D205','D206']:
    d=ordering[ref];s=d['live_schematic_fields'];b=d['pcb_properties'];native=d['native_instance_properties']
    body+=f'### {ref}\n\n| Field | Schematic | PCB |\n|---|---|---|\n'
    for k in ['Value','Description','Datasheet','Package','OEM','OEM PN','LCSC ID']:
        sv=d['live_value'] if k=='Value' else native.get(k,s.get(k,''));body+=f'| {k} | {clean(sv)} | {clean(b.get(k,""))} |\n'
    dnp=next(x for x in read('dnp-comparison.json') if x['ref']==ref);body+=f"| DNP | {dnp['sch_dnp']} | {dnp['pcb_dnp']} |\n\n"

body+='\n## Appendix E. Reproducible commands and complete console output\n\nThe commands below preserve actual paths, working directory, exit codes and stdout/stderr. Use PowerShell’s call operator `&` before a quoted executable when replaying interactively. Version-specific configuration and model overrides are in `kicad9/environment.json`, `kicad10/environment.json` and each `model-environment.json`. Native runs used separate original input copies; changed validator/tests ran from the isolated repaired source.\n\n'
records=[];identity=read('source-identity.json')
for key in ['status','branch','head','remote','remote_head']:records.append(('initial '+key,identity[key]))
records.append(('Git archive source comparison',read('source-archive-command.json')))
for version in [9,10]:
    for p in sorted((RES/f'kicad{version}').glob('*.json')):
        d=json.loads(p.read_text(encoding='utf-8'))
        if isinstance(d,dict) and all(k in d for k in ['command','cwd','exit','stdout','stderr']):records.append((f'KiCad {version}: {p.stem}',d))
for n in ['validator-artwork-before-repair','repaired-manufacturing-validator','repair-regression-tests','repair-patch-check','repair-patch-application-test']:records.append((n,read(n+'.json')))
for key in ['status','branch','head','remote']:records.append(('final '+key,integrity[key]))
for label,d in records:
    body+=f"### {label}\n\nWorking directory: `{d['cwd']}`\n\nExit: **{d['exit']}**\n\n```text\n{d['command']}\n```\n\n"
    for channel in ['stdout','stderr']:
        raw=d[channel].replace('\r\n','\n').replace('\r','');body+=f'{channel}:\n\n```text\n{raw.rstrip() or "(empty)"}\n```\n\n'
body+='\n## Appendix F. Evidence and repair index\n\n'
body+='- `kicad9/` and `kicad10/`: separated native reports, console records, electrical netlists, config and renders.\n- `independent-*.json`, `critical-*.json`, `native-associations.json`: independent geometry, connectivity, metadata, uniqueness and clearance checks.\n- `ci-*.json`: fresh API records for all six runs, jobs and branch sequence.\n- `source-*.json`, `raw-git-blob-comparison.json`, `final-source-integrity.json`: source content, newline handling and preservation evidence.\n- `repair-summary.json`, `repair-regression-tests.json`, `repair-patch-*.json`, `remaining-repairs.patch`: concrete repairs and regression/patch verification.\n- `audit-helpers/`: external audit orchestration. Helpers retain machine-specific paths; adapt paths and supply source/runtime dependencies when reproducing elsewhere.\n\nNegative-test fixture boards are not release inputs and are excluded from delivery. The source ZIP and patch identify the additional local repairs separately from the upstream commit.\n'
report=OUT/(name+'.md');report.write_text(body,encoding='utf-8')
def zip_verified(path,entries):
    assert 'SHA256SUMS.txt' not in entries
    manifest=''.join(f'{hashlib.sha256(data).hexdigest()}  {n}\n' for n,data in sorted(entries.items()));entries['SHA256SUMS.txt']=manifest.encode()
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,data in sorted(entries.items()):z.writestr(n,data)
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        for line in z.read('SHA256SUMS.txt').decode().splitlines():
            h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h
    return len(entries)
evidence={report.name:report.read_bytes()};allowed={'.json','.rpt','.md','.svg','.png','.txt','.xml','.patch'}
for p in RES.rglob('*'):
    if not p.is_file() or p.stat().st_size==0:continue
    rel=p.relative_to(RES)
    if 'temp' in rel.parts:continue
    if p.suffix in allowed or p.name in ['sym-lib-table','fp-lib-table']:evidence['evidence/'+rel.as_posix()]=p.read_bytes()
for n in ['audit_helpers.py','run_live.py','redirect_report.py','independent_review.py','inspect_geometry.py','extra_checks.py','closure_review.py','label_geometry.py','verify_ci.py','probe_validator.py','repair_remaining.py','check_repairs.py','package_patch.py','test_patch_application.py','finish_checks.py','package_report.py','write_report_main.py','render_views.cjs','crop_views.cjs']:
    evidence['audit-helpers/'+n]=(BASE/n).read_bytes()
evidence['audit-helpers/start_9bde764.py']=(BASE.parent/'start_9bde764.py').read_bytes()
evidence['README.txt']=(f'Read {report.name} first.\nBase commit {COMMIT}, plus isolated local script/document/test repairs.\nEvidence only: no native source, invalid test fixture boards or fabrication files.\nRepaired source is delivered in a separate source ZIP.\n').encode()
forbidden={'.gbr','.gbl','.gtl','.gbs','.gts','.gbo','.gto','.drl','.xln','.pos','.ger','.gerber','.csv','.zip'}
assert not any(Path(n).suffix.lower() in forbidden|{'.kicad_pcb','.kicad_sch'} for n in evidence)
ezip=OUT/(name+'_Evidence.zip');ecount=zip_verified(ezip,evidence)
source={p.relative_to(BASE/'repaired-source').as_posix():p.read_bytes() for p in (BASE/'repaired-source').rglob('*') if p.is_file()}
assert len(source)==311 and not any(Path(n).suffix.lower() in forbidden for n in source)
source['AUDIT_REPAIRS.md']=(f'# Independently audited source with local repairs\n\nBase: `{COMMIT}`. Read the separate `{report.name}` for the final PASS scope and physical test gates.\n\nNative KiCad, library and project files are unchanged from the audited package. Three tracked files were modified and one regression test added; see `AUDIT_REPAIRS.json`. Changes have not been committed or pushed.\n\nThe fresh report supersedes stored historical review claims where they differ. Run the primary release checks with KiCad 9; keep any KiCad 10 use on a separate copy. No manufacturing output is included.\n').encode()
source['AUDIT_REPAIRS.json']=(RES/'repair-summary.json').read_bytes();source['AUDIT_REPAIRS.patch']=(RES/'remaining-repairs.patch').read_bytes()
szip=OUT/(name+'_Repaired_Source.zip');scount=zip_verified(szip,source)
patch=OUT/(name+'_Repairs.patch');shutil.copyfile(RES/'remaining-repairs.patch',patch)
hashfile=OUT/(name+'_SHA256SUMS.txt');hashfile.write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in [report,ezip,szip,patch]),encoding='utf-8')
print(json.dumps({'report':str(report),'words':len(body.split()),'commands':len(records),'evidence':str(ezip),'evidence_members':ecount,'source':str(szip),'source_members':scount,'patch':str(patch),'checksums':str(hashfile)},indent=2))
