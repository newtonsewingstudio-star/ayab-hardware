from pathlib import Path
import re, json, hashlib, subprocess, sys, platform, zipfile, io
BASE=Path(__file__).resolve().parent
SRC=BASE/'source'
RES=BASE/'audit-results'
REPO=Path(r'C:\Users\bjrem\Documents\Codex\2026-09-10\referenced-chatgpt-conversation-this-is-an\work\ayab-hardware-current')
COMMIT='9bde764c6e157920af34ccd1063949ac5dcc5109'
def save(name,data):
    (RES/name).write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
def run(args,cwd=SRC,name=None,env=None):
    p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    entry={'command':subprocess.list2cmdline(list(map(str,args))),'cwd':str(cwd),'exit':p.returncode,'stdout':p.stdout.decode('utf-8','replace'),'stderr':p.stderr.decode('utf-8','replace')}
    if name: save(name+'.json',entry)
    return entry
def parse(path):
    tokens=re.finditer(r'\(|\)|"(?:\\.|[^"\\])*"|[^\s()]+',Path(path).read_text(encoding='utf-8'))
    root=[]; stack=[root]
    for m in tokens:
        t=m.group()
        if t=='(':
            a=[];stack[-1].append(a);stack.append(a)
        elif t==')': stack.pop()
        elif t.startswith('"'):
            stack[-1].append(t[1:-1].replace('\\"','"').replace('\\\\','\\'))
        else: stack[-1].append(t)
    assert len(stack)==1
    return root[0]
def children(x,key): return [a for a in x if isinstance(a,list) and a and a[0]==key]
def child(x,key,default=None): return next(iter(children(x,key)),default if default is not None else [key])
def props(x): return {a[1]:a[2] for a in children(x,'property')}
def native_inventory():
    pcb=parse(SRC/'ayab-esp32/ayab-esp32.kicad_pcb')
    netnames={n[1]:n[2] for n in children(pcb,'net')}
    fps={}
    for f in children(pcb,'footprint'):
        pr=props(f); ref=pr.get('Reference','')
        fps[ref]={'value':pr.get('Value'),'footprint':f[1],'at':child(f,'at')[1:],'layer':child(f,'layer')[1:],'properties':pr,'pads':[{'number':p[1],'type':p[2],'shape':p[3],'at':child(p,'at')[1:],'size':child(p,'size')[1:],'layers':child(p,'layers')[1:],'net':child(p,'net')[1:],'pinfunction':child(p,'pinfunction')[1:]} for p in children(f,'pad')]}
        for p in fps[ref]['pads']:
            if p['net']:
                p['serialized_net_name']=p['net'][-1]
                p['net'][-1]=netnames.get(p['net'][0],p['net'][-1])
    save('native-pcb-footprints.json',fps)
    sheets={}
    for sch in (SRC/'ayab-esp32').glob('*.kicad_sch'):
        s=parse(sch); libs=child(s,'lib_symbols'); libmap={a[1]:a for a in children(libs,'symbol')}
        symbols=[]
        for inst in children(s,'symbol'):
            lid=child(inst,'lib_id')[1];lib=libmap[lid];pins=[]
            for unit in children(lib,'symbol'):
                for p in children(unit,'pin'):
                    pins.append({'number':child(p,'number')[1:],'name':child(p,'name')[1:],'at':child(p,'at')[1:],'type':p[1]})
            symbols.append({'properties':props(inst),'at':child(inst,'at')[1:],'mirror':child(inst,'mirror')[1:],'library_id':lid,'pins':pins,'instances':child(inst,'instances')})
        sheets[sch.name]=symbols
    save('native-schematic-symbols.json',sheets)
    return fps,sheets
def identity():
    checks=[]
    tracked=run(['git','ls-tree','-r','--name-only',COMMIT],REPO)['stdout'].splitlines()
    for rel in tracked:
        p=SRC/rel
        if p.is_file():
            original=subprocess.check_output(['git','show',f'{COMMIT}:{rel}'],cwd=REPO)
            checks.append({'path':rel,'equal':p.read_bytes()==original,'equal_lf':p.read_bytes().replace(b'\r\n',b'\n')==original.replace(b'\r\n',b'\n'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    save('commit-file-comparison.json',checks)
    suffixes={'.gbr','.gbl','.gtl','.gbs','.gts','.gbo','.gto','.drl','.xln','.pos','.ger','.gerber'}
    entries=[]; suspicious=[]
    def inspect_archive(data,prefix):
        with zipfile.ZipFile(data) as z:
            for i in z.infolist():
                if i.is_dir():continue
                path=prefix+i.filename;entries.append(path)
                if Path(i.filename).suffix.lower() in suffixes or re.search(r'(?i)(bom|stencil|cpl|pick.?place|placement).*(csv|tsv|txt|zip)$',i.filename): suspicious.append(path)
                if i.filename.lower().endswith('.zip'):inspect_archive(io.BytesIO(z.read(i)),path+'!/')
    package=Path(r'C:\Users\bjrem\Documents\Codex\2026-09-10\continue-the-ayab-kh910-rev-a\outputs\AYAB_KH910_REV_A_AUDIT_HANDOFF_647998e.zip')
    inspect_archive(package,'')
    save('package-content-audit.json',{'zip_sha256':hashlib.sha256(package.read_bytes()).hexdigest(),'entries_including_nested':entries,'fabrication_candidates':suspicious})
    status={k:run(['git',*args],REPO) for k,args in {'status':['status','--short'],'branch':['branch','--show-current'],'head':['rev-parse','HEAD'],'remote':['remote','-v']}.items()}
    status.update({'python':sys.version,'platform':platform.platform(),'compared_files':len(checks),'mismatches':[x for x in checks if not x['equal_lf']],'newline_only_differences':len([x for x in checks if not x['equal'] and x['equal_lf']])})
    save('identity.json',status)
    print('Compared',len(checks),'files; mismatches',status['mismatches'],'fabrication candidates',suspicious)
if __name__=='__main__':
    identity(); fps,sch=native_inventory();print('Native footprint count',len(fps),'sheets',len(sch))
