import sys,subprocess,hashlib,json,re,difflib,io
from pathlib import Path
base=Path.cwd()/'work/preorder-audit-9bde764';sys.path.insert(0,str(base));from audit_helpers import *
info=json.loads((RES/'repair-summary.json').read_text());patch='';checks=[]
tree=subprocess.check_output(['git','ls-tree','-rz',COMMIT],cwd=REPO)
objects={entry.split(b'\t',1)[1].decode():entry.split(b'\t',1)[0].split()[2].decode() for entry in tree.split(b'\0') if entry}
rows=json.loads((RES/'handoff-git-comparison.json').read_text())['rows']
request=''.join(objects[row['path']]+'\n' for row in rows).encode()
response=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],input=request,cwd=REPO));blobs={}
for row in rows:
 header=response.readline().split();raw=response.read(int(header[2]));assert response.read(1)==b'\n';blobs[row['path']]=raw
for row in rows:
 rel=row['path'];raw=blobs[rel];p=(SRC/rel).read_bytes()
 checks.append({'path':rel,'raw_git_blob_exact':raw==p,'same_after_CRLF_normalization':raw.replace(b'\r\n',b'\n')==p.replace(b'\r\n',b'\n')})
save('raw-git-blob-comparison.json',{'count':len(checks),'exact':sum(x['raw_git_blob_exact'] for x in checks),'normalized':sum(x['same_after_CRLF_normalization'] for x in checks),'rows':checks})
assert all(x['same_after_CRLF_normalization'] for x in checks)
for rel in [*info['changed_tracked_files'],info['added_file']]:
 if rel==info['added_file']:a=b'';b=(BASE/'repaired-source'/rel).read_bytes().replace(b'\r\n',b'\n')
 else:
  a=blobs[rel]
  if rel.endswith('.md'):b=a.replace(b"TP701's `Package`",b"TP703's `Package`")
  else:
   pattern=rb'(    courtyard_hits = \[\]\r?\n    footprint_silk_hits = \[\]\r?\n)    for footprint in physical:'
   b,n=re.subn(pattern,lambda m:m[1]+b'    # Artwork footprints have no component reference but still obstruct silk.\n    for footprint in board.GetFootprints():',a);assert n==1
 patch+='diff --git a/'+rel+' b/'+rel+'\n'
 if not a:patch+='new file mode 100644\n'
 patch+=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+rel if a else '/dev/null',tofile='b/'+rel))
(RES/'remaining-repairs.patch').write_bytes(patch.encode())
r=run(['git','apply','--check',RES/'remaining-repairs.patch'],REPO);save('repair-patch-check.json',r);print(json.dumps({'raw_git_exact':sum(x['raw_git_blob_exact'] for x in checks),'normalized':sum(x['same_after_CRLF_normalization'] for x in checks),'patch_check':r},indent=2));assert r['exit']==0
