from audit_helpers import *
import pcbnew,math,collections
b=pcbnew.LoadBoard(str(SRC/'ayab-esp32/ayab-esp32.kicad_pcb'))
label=next(d for d in b.GetDrawings() if isinstance(d,pcbnew.PCB_TEXT) and d.GetText()=='KH910 REV A 09/2026')
def box(bb):return [pcbnew.ToMM(bb.GetLeft()),pcbnew.ToMM(bb.GetTop()),pcbnew.ToMM(bb.GetRight()),pcbnew.ToMM(bb.GetBottom())]
def inflate(r,m):return [r[0]-m,r[1]-m,r[2]+m,r[3]+m]
def gap(a,c):return math.hypot(max(a[0]-c[2],c[0]-a[2],0),max(a[1]-c[3],c[1]-a[3],0))
r=box(label.GetBoundingBox());shapes=[];courtyards=[]
for f in b.GetFootprints():
    ref=f.GetReference()
    for p in f.Pads():
        if p.IsOnLayer(pcbnew.F_Mask):
            margin=pcbnew.ToMM(p.GetSolderMaskExpansion(pcbnew.F_Mask))
            shapes.append({'ref':ref,'pin':p.GetNumber(),'kind':'front_mask','net':p.GetNetname(),'bbox':inflate(box(p.GetBoundingBox()),margin),'mask_expansion':margin})
    cg=[]
    for g in f.GraphicalItems():
        layer=g.GetLayer()
        if layer==pcbnew.F_CrtYd:cg.append(box(g.GetBoundingBox()))
        if layer in [pcbnew.F_SilkS,pcbnew.F_Fab]:
            if hasattr(g,'IsVisible') and not g.IsVisible():continue
            if layer==pcbnew.F_Fab and hasattr(g,'GetText'):continue
            shapes.append({'ref':ref,'kind':b.GetLayerName(layer),'bbox':box(g.GetBoundingBox())})
    if cg:
        q=[min(a[0] for a in cg),min(a[1] for a in cg),max(a[2] for a in cg),max(a[3] for a in cg)]
        shapes.append({'ref':ref,'kind':'courtyard_envelope','bbox':q});courtyards.append(ref)
    for fld in f.GetFields():
        if fld.GetLayer()==pcbnew.F_SilkS and fld.IsVisible():shapes.append({'ref':ref,'kind':'visible_front_field','text':fld.GetText(),'bbox':box(fld.GetBoundingBox())})
for d in b.GetDrawings():
    if d.GetLayer()==pcbnew.F_SilkS and d.m_Uuid.AsString()!=label.m_Uuid.AsString():shapes.append({'ref':'board','kind':'board_silk','bbox':box(d.GetBoundingBox())})
for s in shapes:s['label_bbox_gap_mm']=gap(r,s['bbox'])
near=sorted(shapes,key=lambda x:x['label_bbox_gap_mm'])[:25]
overlap=[s for s in shapes if s['label_bbox_gap_mm']<=.20]
outline=pcbnew.SHAPE_POLY_SET();assert b.GetBoardPolygonOutlines(outline)
expanded=inflate(r,.2)
corners_inside=all(outline.Contains(pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y))) for x,y in [(expanded[0],expanded[1]),(expanded[2],expanded[1]),(expanded[0],expanded[3]),(expanded[2],expanded[3])])
roots=collections.Counter(f.m_Uuid.AsString() for f in b.GetFootprints())
result={'label_text':label.GetText(),'layer':b.GetLayerName(label.GetLayer()),'at':[pcbnew.ToMM(label.GetPosition().x),pcbnew.ToMM(label.GetPosition().y)],'bbox_mm':r,'margin_mm':.2,'overlaps_or_margin_hits':overlap,'nearest_obstacles':near,'front_courtyards_from_serialized_graphics':len(courtyards),'tested_shapes':len(shapes),'expanded_corners_inside_board':corners_inside,'loaded_footprint_count':sum(roots.values()),'loaded_root_duplicates':{u:c for u,c in roots.items() if c>1}}
save('independent-label-clearance.json',result)
print(json.dumps(result,indent=2))
